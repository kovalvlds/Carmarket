﻿using Carmarket.API.CarService.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using Carmarket.API.CarService.Data;

namespace Carmarket.API.CarService.Controllers
{
    [ApiController]
    [Route("api/auth")]
    public class AuthController : ControllerBase
    {
        private readonly DatabaseConnection _db;

        public AuthController(DatabaseConnection db)
        {
            _db = db;
        }

        [HttpPost("login")]
        public ActionResult<AuthResponseDto> Login([FromBody] LoginRequestDto dto)
        {
            using var conn = _db.GetConnection();
            conn.Open();

            var cmd = new SqlCommand("SELECT Role FROM [User] WHERE Login = @login AND Pass = @pass", conn);
            cmd.Parameters.AddWithValue("@login", dto.Login);
            cmd.Parameters.AddWithValue("@pass", dto.Password);

            object? result = cmd.ExecuteScalar();
            if (result == null)
            {
                return Unauthorized(new AuthResponseDto
                {
                    Success = false,
                    Message = "Невірний логін або пароль"
                });
            }

            bool isDealer = Convert.ToBoolean(result); // ← тут виправлення
            string roleStr = isDealer ? "dealer" : "client";

            return Ok(new AuthResponseDto
            {
                Success = true,
                Role = roleStr,
                Message = "Успішний вхід"
            });
        }

        [HttpPost("signup")]
        public ActionResult<AuthResponseDto> Signup([FromBody] SignupRequestDto dto)
        {
            using var conn = _db.GetConnection();
            conn.Open();

            var checkCmd = new SqlCommand("SELECT COUNT(*) FROM [User] WHERE Login = @login", conn);
            checkCmd.Parameters.AddWithValue("@login", dto.Login);

            int exists = (int)checkCmd.ExecuteScalar();
            if (exists > 0)
            {
                return Conflict(new AuthResponseDto
                {
                    Success = false,
                    Message = "Користувач з таким логіном вже існує"
                });
            }

            var insertCmd = new SqlCommand("INSERT INTO [User] (Login, Pass, Role) VALUES (@login, @pass, @role)", conn);
            insertCmd.Parameters.AddWithValue("@login", dto.Login);
            insertCmd.Parameters.AddWithValue("@pass", dto.Password);
            insertCmd.Parameters.AddWithValue("@role", dto.IsDealer ? 1 : 0);
            insertCmd.ExecuteNonQuery();

            return Ok(new AuthResponseDto
            {
                Success = true,
                Role = dto.IsDealer ? "dealer" : "client",
                Message = "Акаунт успішно створено"
            });
        }

    }
}
