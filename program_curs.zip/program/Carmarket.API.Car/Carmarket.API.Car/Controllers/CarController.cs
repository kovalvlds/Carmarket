﻿using Carmarket.API.CarService.Models;
using Carmarket.API.CarService.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace Carmarket.API.CarService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CarController : ControllerBase
    {
        private readonly ICarService _carService;

        public CarController(ICarService carService)
        {
            _carService = carService;
        }

        [HttpGet("{win}")]
        public ActionResult<Car> GetByWin(string win)
        {
            var car = _carService.GetByWin(win);
            if (car == null) return NotFound();
            return Ok(car);
        }

        [HttpPost]
        public IActionResult Add([FromBody] CarCreateDto dto)
        {
            var car = new Car
            {
                WIN_Number = dto.WIN_Number,
                Mileage = dto.Mileage,
                TechnicalData = dto.TechnicalData,
                NameModel = dto.NameModel,
                ReleaseYear = dto.ReleaseYear,
                Status = dto.Status,
                CarPhoto = dto.CarPhoto
            };

            _carService.Add(car, dto.Login); // ← передаємо логін у сервіс

            return CreatedAtAction(nameof(GetByWin), new { win = car.WIN_Number }, car);
        }

        [HttpPut("status/{win}")]
        public IActionResult UpdateStatus(string win, [FromQuery] string status)
        {
            _carService.UpdateStatus(win, status);
            return NoContent();
        }

        [HttpGet("photo/{win}")]
        public IActionResult GetPhoto(string win)
        {
            var photo = _carService.GetPhoto(win);
            if (photo == null)
                return NotFound();

            return File(photo, "image/jpeg"); // або image/png
        }

        [HttpDelete("{win}")]
        public IActionResult Delete(string win)
        {
            _carService.Delete(win);
            return NoContent();
        }

        [HttpPut]
        public IActionResult Update([FromBody] CarUpdateDto dto)
        {
            _carService.Update(dto);
            return NoContent();
        }

        [HttpGet("by-dealer")]
        public ActionResult<IEnumerable<CarDto>> GetByDealer([FromQuery] string login, [FromQuery] string? search = null)
        {
            var result = _carService.GetCarsByDealer(login, search);

            if (!result.Any())
                return NotFound();

            return Ok(result);
        }

    }
}
