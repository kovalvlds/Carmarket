﻿using Carmarket.API.CarService.Data;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using Carmarket.API.CarService.Models;


namespace Carmarket.API.CarService.Controllers
{
    [ApiController]
    [Route("api/city")]
    public class CityController : ControllerBase
    {
        private readonly DatabaseConnection _db;

        public CityController(DatabaseConnection db)
        {
            _db = db;
        }

        [HttpGet]
        public ActionResult<IEnumerable<string>> GetAll()
        {
            List<string> cities = new();

            using var conn = _db.GetConnection();
            conn.Open();

            var cmd = new SqlCommand("SELECT NameCity FROM City", conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                cities.Add(reader.GetString(0));
            }

            return Ok(cities);
        }

        [HttpPost]
        public IActionResult AddCity([FromBody] CityDto dto)
        {
            using var conn = _db.GetConnection();
            conn.Open();

            var cmd = new SqlCommand("INSERT INTO City (NameCity) VALUES (@name)", conn);
            cmd.Parameters.AddWithValue("@name", dto.NameCity);

            try
            {
                cmd.ExecuteNonQuery();
                return Ok();
            }
            catch (SqlException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        [HttpDelete("{name}")]
        public IActionResult DeleteCity(string name)
        {
            using var conn = _db.GetConnection();
            conn.Open();

            var cmd = new SqlCommand("DELETE FROM City WHERE NameCity = @name", conn);
            cmd.Parameters.AddWithValue("@name", name);

            try
            {
                int affected = cmd.ExecuteNonQuery();
                return affected > 0 ? Ok() : NotFound();
            }
            catch (SqlException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }
    }
}

