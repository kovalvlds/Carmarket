﻿using Carmarket.API.CarService.Data;
using Carmarket.API.CarService.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;

namespace Carmarket.API.CarService.Controllers
{
    [ApiController]
    [Route("api/client")]
    public class ClientController : ControllerBase
    {
        private readonly DatabaseConnection _db;

        public ClientController(DatabaseConnection db)
        {
            _db = db;
        }

        [HttpPost("profile")]
        public IActionResult SaveClientProfile([FromBody] ClientProfileDto dto)
        {
            using var conn = _db.GetConnection();
            conn.Open();

            var insertCmd = new SqlCommand(@"
                INSERT INTO Client (LastName, Name, MiddleName, Address, Email, Login, NameCity, ClientPhone)
                VALUES (@last, @name, @middle, @addr, @mail, @login, @city, @phone)
            ", conn);

            insertCmd.Parameters.AddWithValue("@last", dto.LastName);
            insertCmd.Parameters.AddWithValue("@name", dto.Name);
            insertCmd.Parameters.AddWithValue("@middle", dto.MiddleName);
            insertCmd.Parameters.AddWithValue("@addr", dto.Address);
            insertCmd.Parameters.AddWithValue("@mail", dto.Email);
            insertCmd.Parameters.AddWithValue("@login", dto.Login);
            insertCmd.Parameters.AddWithValue("@city", dto.NameCity);
            insertCmd.Parameters.AddWithValue("@phone", dto.ClientPhone);

            try
            {
                insertCmd.ExecuteNonQuery();
                return Ok(new { Message = "Анкета клієнта збережена." });
            }
            catch (SqlException ex)
            {
                return BadRequest(new { Error = "Помилка при збереженні анкети", ex.Message });
            }
        }

        [HttpGet("all")]
        public ActionResult<IEnumerable<ClientDto>> GetAllClients()
        {
            var list = new List<ClientDto>();
            using var conn = _db.GetConnection();
            conn.Open();

            var cmd = new SqlCommand("SELECT * FROM Client", conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new ClientDto
                {
                    IdClient = (int)reader["IdClient"],
                    LastName = reader["LastName"].ToString(),
                    Name = reader["Name"].ToString(),
                    MiddleName = reader["MiddleName"].ToString(),
                    Address = reader["Address"].ToString(),
                    Email = reader["Email"].ToString(),
                    Login = reader["Login"].ToString(),
                    NameCity = reader["NameCity"].ToString(),
                    ClientPhone = reader["ClientPhone"].ToString()
                });
            }

            return Ok(list);
        }

    }
}

