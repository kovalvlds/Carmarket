﻿using Carmarket.API.CarService.Models;
using Carmarket.API.CarService.Services;
using Microsoft.AspNetCore.Mvc;

namespace Carmarket.API.CarService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ContractController : ControllerBase
    {
        private readonly IContractService _contractService;

        public ContractController(IContractService contractService)
        {
            _contractService = contractService;
        }

        [HttpGet]
        public ActionResult<IEnumerable<ContractDto>> GetAll()
        {
            return Ok(_contractService.GetAll());
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _contractService.Delete(id);
            return NoContent();
        }

        [HttpGet("by-dealer")]
        public ActionResult<IEnumerable<MyContractDto>> GetByDealer([FromQuery] string login)
        {
            var result = _contractService.GetByDealerLogin(login);
            if (!result.Any())
                return NotFound();

            return Ok(result);
        }

    }
}
