﻿using Carmarket.API.CarService.Data;
using Carmarket.API.CarService.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;

namespace Carmarket.API.CarService.Controllers
{
    [ApiController]
    [Route("api/dealer")]
    public class DealerController : ControllerBase
    {
        private readonly DatabaseConnection _db;

        public DealerController(DatabaseConnection db)
        {
            _db = db;
        }

        [HttpPost("profile")]
        public IActionResult SaveDealerProfile([FromBody] DealerProfileDto dto)
        {
            using var conn = _db.GetConnection();
            conn.Open();

            var insertCmd = new SqlCommand(@"
                INSERT INTO Dealer (LastName, Name, MiddleName, HomeAdress, Login, DealerPhone)
                VALUES (@last, @name, @middle, @adress, @login, @phone)
            ", conn);

            insertCmd.Parameters.AddWithValue("@last", dto.LastName);
            insertCmd.Parameters.AddWithValue("@name", dto.Name);
            insertCmd.Parameters.AddWithValue("@middle", dto.MiddleName);
            insertCmd.Parameters.AddWithValue("@adress", dto.HomeAdress);
            insertCmd.Parameters.AddWithValue("@login", dto.Login);
            insertCmd.Parameters.AddWithValue("@phone", dto.DealerPhone);

            try
            {
                insertCmd.ExecuteNonQuery();
                return Ok(new { Message = "Анкета дилера збережена." });
            }
            catch (SqlException ex)
            {
                return BadRequest(new { Error = "Помилка при збереженні анкети", ex.Message });
            }
        }

        [HttpGet("all")]
        public ActionResult<IEnumerable<DealerDto>> GetAllDealers()
        {
            var list = new List<DealerDto>();
            using var conn = _db.GetConnection();
            conn.Open();

            var cmd = new SqlCommand("SELECT * FROM Dealer", conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new DealerDto
                {
                    IdDealer = (int)reader["IdDealer"],
                    LastName = reader["LastName"].ToString(),
                    Name = reader["Name"].ToString(),
                    MiddleName = reader["MiddleName"].ToString(),
                    HomeAdress = reader["HomeAdress"].ToString(),
                    Login = reader["Login"].ToString(),
                    DealerPhone = reader["DealerPhone"].ToString()
                });
            }

            return Ok(list);
        }

    }
}
