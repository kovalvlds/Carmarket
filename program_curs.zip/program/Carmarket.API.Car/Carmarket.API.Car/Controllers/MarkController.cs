﻿using Carmarket.API.CarService.Data;
using Carmarket.API.CarService.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;

namespace Carmarket.API.CarService.Controllers
{
    [ApiController]
    [Route("api/mark")]
    public class MarkController : ControllerBase
    {
        private readonly DatabaseConnection _db;

        public MarkController(DatabaseConnection db)
        {
            _db = db;
        }

        [HttpGet]
        public ActionResult<IEnumerable<string>> GetAll()
        {
            List<string> marks = new();
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand("SELECT Mark FROM Mark", conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                marks.Add(reader.GetString(0));
            }
            return Ok(marks);
        }

        [HttpPost]
        public IActionResult Add([FromBody] MarkDto dto)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand("INSERT INTO Mark (Mark) VALUES (@mark)", conn);
            cmd.Parameters.AddWithValue("@mark", dto.Mark);
            try
            {
                cmd.ExecuteNonQuery();
                return Ok();
            }
            catch (SqlException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        [HttpDelete("{mark}")]
        public IActionResult Delete(string mark)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand("DELETE FROM Mark WHERE Mark = @mark", conn);
            cmd.Parameters.AddWithValue("@mark", mark);
            try
            {
                int affected = cmd.ExecuteNonQuery();
                return affected > 0 ? Ok() : NotFound();
            }
            catch (SqlException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }
    }
        
}

