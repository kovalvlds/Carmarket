﻿using Carmarket.API.CarService.Models;
using Carmarket.API.CarService.Services;
using Microsoft.AspNetCore.Mvc;

namespace Carmarket.API.CarService.Controllers
{
    [ApiController]
    [Route("api/market")]
    public class MarketController : ControllerBase
    {
        private readonly IMarketService _service;

        public MarketController(IMarketService service)
        {
            _service = service;
        }

        [HttpGet]
        public ActionResult<IEnumerable<MarketCarDto>> Get()
        {
            return Ok(_service.GetAllActiveForMarket());
        }

        [HttpGet("photo/{win}")]
        public IActionResult GetPhoto(string win)
        {
            var photo = _service.GetPhoto(win);
            if (photo == null) return NotFound();
            return File(photo, "image/jpeg");
        }

        [HttpPost("contract")]
        public IActionResult Buy([FromBody] CreateContractDto dto)
        {
            try
            {
                _service.CreateContract(dto);
                return Ok(new { Message = "Контракт створено" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { Error = ex.Message });
            }
        }
    }
}
