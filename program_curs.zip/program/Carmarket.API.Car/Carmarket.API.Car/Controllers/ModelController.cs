﻿using Carmarket.API.CarService.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Microsoft.AspNetCore.Mvc;
using Carmarket.API.CarService.Data;

namespace Carmarket.API.CarService.Controllers
{
    [ApiController]
    [Route("api/model")]
    public class ModelController : ControllerBase
    {
        private readonly DatabaseConnection _db;

        public ModelController(DatabaseConnection db)
        {
            _db = db;
        }

        [HttpGet]
        public ActionResult<IEnumerable<ModelDto>> GetAll()
        {
            List<ModelDto> models = new();
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand("SELECT NameModel, Mark FROM Model", conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                models.Add(new ModelDto
                {
                    NameModel = reader.GetString(0),
                    Mark = reader.GetString(1)
                });
            }
            return Ok(models);
        }

        [HttpPost]
        public IActionResult Add([FromBody] ModelDto dto)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand("INSERT INTO Model (NameModel, Mark) VALUES (@model, @mark)", conn);
            cmd.Parameters.AddWithValue("@model", dto.NameModel);
            cmd.Parameters.AddWithValue("@mark", dto.Mark);

            try
            {
                cmd.ExecuteNonQuery();
                return Ok();
            }
            catch (SqlException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        [HttpDelete("{nameModel}")]
        public IActionResult Delete(string nameModel)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand("DELETE FROM Model WHERE NameModel = @model", conn);
            cmd.Parameters.AddWithValue("@model", nameModel);

            try
            {
                int affected = cmd.ExecuteNonQuery();
                return affected > 0 ? Ok() : NotFound();
            }
            catch (SqlException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }
    }

}

