﻿using Carmarket.API.CarService.Models;
using Carmarket.API.CarService.Services;
using Microsoft.AspNetCore.Mvc;

namespace Carmarket.API.CarService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SaleController : ControllerBase
    {
        private readonly ISaleService _saleService;

        public SaleController(ISaleService saleService)
        {
            _saleService = saleService;
        }

        // GET: всі авто на продаж
        [HttpGet]
        public ActionResult<IEnumerable<SaleDto>> GetAll()
        {
            var result = _saleService.GetAll();
            return Ok(result);
        }

        // GET: авто на продаж для конкретного WIN (опціонально)
        [HttpGet("{win}")]
        public ActionResult<SaleDto> GetByWin(string win)
        {
            var result = _saleService.GetLatestByWin(win);
            if (result == null)
                return NotFound();

            return Ok(result);
        }

        // POST: додати авто на продаж
        [HttpPost]
        public IActionResult AddSale([FromBody] AddSaleDto dto)
        {
            _saleService.Add(dto);
            return Ok(new { message = "Успішно додано на продаж" });
        }

        // DELETE: зняти авто з продажу
        [HttpDelete]
        public IActionResult Delete([FromQuery] string win, [FromQuery] string date)
        {
            _saleService.Delete(win, date);
            return Ok(new { message = "Авто знято з продажу" });
        }
    }
}

