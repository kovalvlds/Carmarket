﻿using Carmarket.API.CarService.Models;
using Carmarket.API.CarService.Services;
using Microsoft.AspNetCore.Mvc;

namespace Carmarket.API.CarService.Controllers
{
    [ApiController]
    [Route("api/stat")]
    public class StatisticController : ControllerBase
    {
        private readonly IStatisticService _stat;

        public StatisticController(IStatisticService stat)
        {
            _stat = stat;
        }

        [HttpGet("monthly")]
        public ActionResult<IEnumerable<MonthStatDto>> GetMonthlyContracts()
        {
            return Ok(_stat.GetContractsByMonth());
        }

        [HttpGet("dealer")]
        public ActionResult<IEnumerable<DealerEarningsDto>> GetDealerEarnings()
        {
            return Ok(_stat.GetDealerEarnings());
        }

        [HttpGet("client")]
        public ActionResult<IEnumerable<ClientContractsDto>> GetClientContractCounts()
        {
            return Ok(_stat.GetClientContractCounts());
        }
    }
}
