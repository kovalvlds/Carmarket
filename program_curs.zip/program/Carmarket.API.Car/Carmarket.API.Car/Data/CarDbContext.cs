﻿using Carmarket.API.CarService.Models;
using Microsoft.EntityFrameworkCore;

namespace Carmarket.API.CarService.Data
{
    public class CarDbContext : DbContext
    {
        public CarDbContext(DbContextOptions<CarDbContext> options) : base(options)
        {
        }

        public DbSet<Car> Cars { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Car>().ToTable("Car"); // 👈 явно вказуємо назву таблиці
        }
    }
}
