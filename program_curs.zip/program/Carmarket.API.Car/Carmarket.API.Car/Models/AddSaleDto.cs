﻿namespace Carmarket.API.CarService.Models
{
    public class AddSaleDto
    {
        public string WIN_Number { get; set; } = null!;
        public string IssueDate { get; set; } = null!; // yyyy-MM-dd
        public string Login { get; set; } = null!;     // дилер логін
        public decimal Price { get; set; }
    }
}
