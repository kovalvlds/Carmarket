﻿namespace Carmarket.API.CarService.Models
{
    public class AuthResponseDto
    {
        public bool Success { get; set; }
        public string? Role { get; set; } // \"dealer\" або \"client\"
        public string Message { get; set; } = null!;
    }
}

