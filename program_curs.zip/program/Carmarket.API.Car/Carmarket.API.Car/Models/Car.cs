﻿using System.ComponentModel.DataAnnotations;

namespace Carmarket.API.CarService.Models
{
    public class Car
    {
        [Key]
        public string WIN_Number { get; set; } = null!;
        public int Mileage { get; set; }
        public string TechnicalData { get; set; } = null!;
        public string NameModel { get; set; } = null!;
        public int ReleaseYear { get; set; }
        public byte[]? CarPhoto { get; set; }
        public string Status { get; set; } = "неактивна";
    }
}
