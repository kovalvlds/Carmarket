﻿namespace Carmarket.API.CarService.Models
{
    public class CarCreateDto
    {
        public string WIN_Number { get; set; } = null!;
        public int Mileage { get; set; }
        public string TechnicalData { get; set; } = null!;
        public string NameModel { get; set; } = null!;
        public int ReleaseYear { get; set; }
        public string Status { get; set; } = "неактивна";
        public byte[]? CarPhoto { get; set; }
        public string Login { get; set; } = null!; 
    }

}
