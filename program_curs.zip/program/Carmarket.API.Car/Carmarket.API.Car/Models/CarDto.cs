﻿namespace Carmarket.API.CarService.Models
{
    public class CarDto
    {
        public string WIN_Number { get; set; }
        public int Mileage { get; set; }
        public string TechnicalData { get; set; }
        public string NameModel { get; set; }
        public string Mark { get; set; }
        public string Status { get; set; }
        public int ReleaseYear { get; set; }
    }
}
