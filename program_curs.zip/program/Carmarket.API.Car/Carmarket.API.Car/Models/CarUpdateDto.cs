﻿namespace Carmarket.API.CarService.Models
{
    public class CarUpdateDto
    {
        public string WIN_Number { get; set; } = null!;
        public int Mileage { get; set; }
        public string TechnicalData { get; set; } = null!;
        public string Status { get; set; } = null!;
        public int ReleaseYear { get; set; }
    }
}
