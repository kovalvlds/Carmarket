﻿namespace Carmarket.API.CarService.Models
{
    public class CityDto
    {
        public string NameCity { get; set; } = null!;
    }
}
