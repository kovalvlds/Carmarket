﻿namespace Carmarket.API.CarService.Models
{
    public class ClientContractsDto
    {
        public int IdClient { get; set; }
        public int ContractCount { get; set; }
    }
}

