﻿namespace Carmarket.API.CarService.Models
{
    public class ClientProfileDto
    {
        public string LastName { get; set; } = null!;
        public string Name { get; set; } = null!;
        public string MiddleName { get; set; } = null!;
        public string Address { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string Login { get; set; } = null!;
        public string NameCity { get; set; } = null!;
        public string ClientPhone { get; set; } = null!;
    }
}

