﻿namespace Carmarket.API.CarService.Models
{
    public class ContractDto
    {
        public int IdContract { get; set; }
        public DateTime ContractDate { get; set; }
        public int IdClient { get; set; }
        public string WIN_Number { get; set; } = null!;
        public DateTime IssueDate { get; set; }
    }
}

