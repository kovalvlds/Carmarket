﻿namespace Carmarket.API.CarService.Models
{
    public class CreateContractDto
    {
        public string WIN_Number { get; set; }
        public string Login { get; set; }
        public DateTime IssueDate { get; set; }
        public DateTime ContractDate { get; set; }
    }

}
