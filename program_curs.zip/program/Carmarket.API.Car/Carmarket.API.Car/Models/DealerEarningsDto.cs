﻿namespace Carmarket.API.CarService.Models
{
    public class DealerEarningsDto
    {
        public int IdDealer { get; set; }
        public decimal Earnings { get; set; }
    }
}
