﻿namespace Carmarket.API.CarService.Models
{
    public class DealerProfileDto
    {
        public string LastName { get; set; } = null!;
        public string Name { get; set; } = null!;
        public string MiddleName { get; set; } = null!;
        public string HomeAdress { get; set; } = null!;
        public string Login { get; set; } = null!;
        public string DealerPhone { get; set; } = null!;
    }
}

