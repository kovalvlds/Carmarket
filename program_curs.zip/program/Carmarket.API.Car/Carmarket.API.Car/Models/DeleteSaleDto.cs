﻿namespace Carmarket.API.CarService.Models
{
    public class DeleteSaleDto
    {
        public string WIN_Number { get; set; } = null!;
        public string IssueDate { get; set; } = null!; // yyyy-MM-dd
    }
}

