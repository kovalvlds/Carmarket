﻿namespace Carmarket.API.CarService.Models
{
    public class LoginRequestDto
    {
        public string Login { get; set; } = null!;
        public string Password { get; set; } = null!;
    }
}

