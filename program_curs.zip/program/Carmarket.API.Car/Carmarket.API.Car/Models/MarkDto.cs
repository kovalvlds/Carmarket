﻿namespace Carmarket.API.CarService.Models
{
    public class MarkDto
    {
        public string Mark { get; set; } = null!;
    }
}
