﻿namespace Carmarket.API.CarService.Models
{
    public class ModelDto
    {
        public string NameModel { get; set; } = null!;
        public string Mark { get; set; } = null!;
    }
}
