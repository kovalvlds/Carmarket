﻿namespace Carmarket.API.CarService.Models
{
    public class MonthStatDto
    {
        public int Month { get; set; }
        public int ContractCount { get; set; }
    }
}
