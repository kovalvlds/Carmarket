﻿namespace Carmarket.API.CarService.Models
{
    public class MyContractDto
    {
        public int IdContract { get; set; }
        public string LNameCl { get; set; } = null!;
        public string WIN_Number { get; set; } = null!;
        public string NameModel { get; set; } = null!;
        public decimal Price { get; set; }
        public DateTime ContractDate { get; set; }
        public DateTime IssueDate { get; set; }
    }
}

