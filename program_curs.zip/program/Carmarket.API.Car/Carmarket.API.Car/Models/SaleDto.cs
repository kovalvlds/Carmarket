﻿namespace Carmarket.API.CarService.Models
{
    public class SaleDto
    {
        public string WIN_Number { get; set; } = null!;
        public string IssueDate { get; set; } = null!;
        public int IdDealer { get; set; }
        public decimal Price { get; set; }
    }
}

