﻿namespace Carmarket.API.CarService.Models
{
    public class SignupRequestDto
    {
        public string Login { get; set; } = null!;
        public string Password { get; set; } = null!;
        public string LastName { get; set; } = null!;
        public bool IsDealer { get; set; } // true => Dealer, false => Client
    }
}

