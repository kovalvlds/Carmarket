﻿using Carmarket.API.CarService.Data;
using Microsoft.EntityFrameworkCore;
using Carmarket.API.CarService.Services;

var builder = WebApplication.CreateBuilder(args);

// Підключення сервісів
builder.Services.AddScoped<DatabaseConnection>();
builder.Services.AddScoped<ICarService, CarService>();

builder.Services.AddControllers();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddScoped<ISaleService, SaleService>();
builder.Services.AddScoped<IContractService, ContractService>();
builder.Services.AddScoped<IStatisticService, StatisticService>();
builder.Services.AddScoped<IMarketService, MarketService>();




var app = builder.Build();

// Swagger
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();
