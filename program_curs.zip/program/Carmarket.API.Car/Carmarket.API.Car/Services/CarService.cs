﻿using Carmarket.API.CarService.Data;
using Carmarket.API.CarService.Models;
using System.Data.SqlClient;

namespace Carmarket.API.CarService.Services
{
    public class CarService : ICarService
    {
        private readonly DatabaseConnection _connection;

        public CarService(DatabaseConnection connection)
        {
            _connection = connection;
        }

        public IEnumerable<Car> GetAllActiveCars()
        {
            List<Car> cars = new List<Car>();

            using (SqlConnection conn = _connection.GetConnection())
            {
                conn.Open();
                string query = "SELECT * FROM Car WHERE Status = 'активна'";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        cars.Add(new Car
                        {
                            WIN_Number = reader["WIN_Number"].ToString()!,
                            Mileage = Convert.ToInt32(reader["Mileage"]),
                            TechnicalData = reader["TechnicalData"].ToString()!,
                            NameModel = reader["NameModel"].ToString()!,
                            ReleaseYear = Convert.ToInt32(reader["ReleaseYear"]),
                            Status = reader["Status"].ToString()!,
                            CarPhoto = reader["CarPhoto"] == DBNull.Value ? null : (byte[])reader["CarPhoto"]
                        });
                    }
                }
            }

            return cars;
        }

        public Car? GetByWin(string win)
        {
            using (SqlConnection conn = _connection.GetConnection())
            {
                conn.Open();
                string query = "SELECT * FROM Car WHERE WIN_Number = @win";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@win", win);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Car
                            {
                                WIN_Number = reader["WIN_Number"].ToString()!,
                                Mileage = Convert.ToInt32(reader["Mileage"]),
                                TechnicalData = reader["TechnicalData"].ToString()!,
                                NameModel = reader["NameModel"].ToString()!,
                                ReleaseYear = Convert.ToInt32(reader["ReleaseYear"]),
                                Status = reader["Status"].ToString()!,
                                CarPhoto = reader["CarPhoto"] == DBNull.Value ? null : (byte[])reader["CarPhoto"]
                            };
                        }
                    }
                }
            }

            return null;
        }

        public void Add(Car car, string dealerLogin)
        {
            using (SqlConnection conn = _connection.GetConnection())
            {
                conn.Open();

                // Перевірка на існування авто
                string checkQuery = "SELECT COUNT(*) FROM Car WHERE WIN_Number = @win";
                using (SqlCommand checkCmd = new SqlCommand(checkQuery, conn))
                {
                    checkCmd.Parameters.AddWithValue("@win", car.WIN_Number);
                    int count = (int)checkCmd.ExecuteScalar();
                    if (count > 0)
                        throw new Exception($"Авто з WIN '{car.WIN_Number}' вже існує.");
                }

                // Додавання авто
                string query = @"INSERT INTO Car (WIN_Number, Mileage, TechnicalData, NameModel, ReleaseYear, CarPhoto, Status) 
                         VALUES (@win, @mileage, @tech, @model, @year, @photo, @status)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@win", car.WIN_Number);
                    cmd.Parameters.AddWithValue("@mileage", car.Mileage);
                    cmd.Parameters.AddWithValue("@tech", car.TechnicalData);
                    cmd.Parameters.AddWithValue("@model", car.NameModel);
                    cmd.Parameters.AddWithValue("@year", car.ReleaseYear);
                    cmd.Parameters.AddWithValue("@photo", (object?)car.CarPhoto ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@status", car.Status);
                    cmd.ExecuteNonQuery();
                }

                // Отримуємо Id дилера
                string getDealerQuery = "SELECT IdDealer FROM Dealer WHERE Login = @login";
                using (SqlCommand dealerCmd = new SqlCommand(getDealerQuery, conn))
                {
                    dealerCmd.Parameters.AddWithValue("@login", dealerLogin);
                    object? result = dealerCmd.ExecuteScalar();

                    if (result != null)
                    {
                        int dealerId = Convert.ToInt32(result);

                        // Вставка в DealerCars
                        string dealerCarsQuery = "INSERT INTO DealerCars (WIN_Number, IdDealer) VALUES (@win, @id)";
                        using (SqlCommand insertCmd = new SqlCommand(dealerCarsQuery, conn))
                        {
                            insertCmd.Parameters.AddWithValue("@win", car.WIN_Number);
                            insertCmd.Parameters.AddWithValue("@id", dealerId);
                            insertCmd.ExecuteNonQuery();
                        }
                    }
                }
            }
        }



        public void UpdateStatus(string win, string status)
        {
            using (SqlConnection conn = _connection.GetConnection())
            {
                conn.Open();
                string query = "UPDATE Car SET Status = @status WHERE WIN_Number = @win";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@status", status);
                    cmd.Parameters.AddWithValue("@win", win);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public byte[]? GetPhoto(string win)
        {
            using (SqlConnection conn = _connection.GetConnection())
            {
                conn.Open();
                string query = "SELECT CarPhoto FROM Car WHERE WIN_Number = @win";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@win", win);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read() && reader["CarPhoto"] != DBNull.Value)
                        {
                            return (byte[])reader["CarPhoto"];
                        }
                    }
                }
            }

            return null;
        }

        public IEnumerable<CarDto> GetCarsByDealer(string login)
        {
            List<CarDto> cars = new();

            using (SqlConnection conn = _connection.GetConnection())
            {
                conn.Open();

                string query = @"
            SELECT c.WIN_Number, c.Mileage, c.TechnicalData, c.NameModel, m.Mark, c.Status, c.ReleaseYear
            FROM Car c
            INNER JOIN Model m ON c.NameModel = m.NameModel
            INNER JOIN DealerCars dc ON c.WIN_Number = dc.WIN_Number
            INNER JOIN Dealer d ON dc.IdDealer = d.IdDealer
            WHERE d.Login = @login";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@login", login);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            cars.Add(new CarDto
                            {
                                WIN_Number = reader.GetString(0),
                                Mileage = reader.GetInt32(1),
                                TechnicalData = reader.GetString(2),
                                NameModel = reader.GetString(3),
                                Mark = reader.GetString(4),
                                Status = reader.GetString(5),
                                ReleaseYear = reader.GetInt32(6)
                            });
                        }
                    }
                }
            }

            return cars;
        }

        public void Delete(string win)
        {
            using (SqlConnection conn = _connection.GetConnection())
            {
                conn.Open();

                // Видалення з DealerCars (щоб не було зовнішнього ключа)
                var deleteDealerCars = "DELETE FROM DealerCars WHERE WIN_Number = @win";
                using (SqlCommand cmd = new SqlCommand(deleteDealerCars, conn))
                {
                    cmd.Parameters.AddWithValue("@win", win);
                    cmd.ExecuteNonQuery();
                }

                // Видалення з Car
                var deleteCar = "DELETE FROM Car WHERE WIN_Number = @win";
                using (SqlCommand cmd = new SqlCommand(deleteCar, conn))
                {
                    cmd.Parameters.AddWithValue("@win", win);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        public void Update(CarUpdateDto dto)
        {
            using (SqlConnection conn = _connection.GetConnection())
            {
                conn.Open();

                string query = @"UPDATE Car 
                         SET Mileage = @mileage, 
                             TechnicalData = @tech, 
                             Status = @status, 
                             ReleaseYear = @year 
                         WHERE WIN_Number = @win";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@mileage", dto.Mileage);
                    cmd.Parameters.AddWithValue("@tech", dto.TechnicalData);
                    cmd.Parameters.AddWithValue("@status", dto.Status);
                    cmd.Parameters.AddWithValue("@year", dto.ReleaseYear);
                    cmd.Parameters.AddWithValue("@win", dto.WIN_Number);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public IEnumerable<CarDto> GetCarsByDealer(string login, string? search = null)
        {
            List<CarDto> cars = new();

            using (SqlConnection conn = _connection.GetConnection())
            {
                conn.Open();

                string query = @"
            SELECT c.WIN_Number, c.Mileage, c.TechnicalData, c.NameModel, m.Mark, c.Status, c.ReleaseYear
            FROM Car c
            INNER JOIN Model m ON c.NameModel = m.NameModel
            INNER JOIN DealerCars dc ON c.WIN_Number = dc.WIN_Number
            INNER JOIN Dealer d ON dc.IdDealer = d.IdDealer
            WHERE d.Login = @login";

                if (!string.IsNullOrEmpty(search))
                {
                    query += @" AND (
                c.WIN_Number LIKE @search OR
                c.TechnicalData LIKE @search OR
                c.NameModel LIKE @search OR
                m.Mark LIKE @search OR
                c.Status LIKE @search
            )";
                }

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@login", login);
                    if (!string.IsNullOrEmpty(search))
                        cmd.Parameters.AddWithValue("@search", $"%{search}%");

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            cars.Add(new CarDto
                            {
                                WIN_Number = reader.GetString(0),
                                Mileage = reader.GetInt32(1),
                                TechnicalData = reader.GetString(2),
                                NameModel = reader.GetString(3),
                                Mark = reader.GetString(4),
                                Status = reader.GetString(5),
                                ReleaseYear = reader.GetInt32(6)
                            });
                        }
                    }
                }
            }

            return cars;
        }


    }
}
