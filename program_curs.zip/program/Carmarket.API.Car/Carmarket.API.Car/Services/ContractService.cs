﻿using System.Data.SqlClient;
using Carmarket.API.CarService.Data;
using Carmarket.API.CarService.Models;

namespace Carmarket.API.CarService.Services
{
    public class ContractService : IContractService
    {
        private readonly DatabaseConnection _db;

        public ContractService(DatabaseConnection db)
        {
            _db = db;
        }

        public IEnumerable<ContractDto> GetAll()
        {
            var contracts = new List<ContractDto>();

            using (var conn = _db.GetConnection())
            {
                conn.Open();

                string query = "SELECT IdContract, ContractDate, IdClient, WIN_Number, IssueDate FROM Contract";

                using (var cmd = new SqlCommand(query, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        contracts.Add(new ContractDto
                        {
                            IdContract = reader.GetInt32(0),
                            ContractDate = reader.GetDateTime(1),
                            IdClient = reader.GetInt32(2),
                            WIN_Number = reader.GetString(3),
                            IssueDate = reader.GetDateTime(4)
                        });
                    }
                }
            }

            return contracts;
        }

        public void Delete(int id)
        {
            using (var conn = _db.GetConnection())
            {
                conn.Open();

                string query = "DELETE FROM Contract WHERE IdContract = @id";

                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public IEnumerable<MyContractDto> GetByDealerLogin(string login)
        {
            var contracts = new List<MyContractDto>();

            using (var conn = _db.GetConnection())
            {
                conn.Open();

                string query = @"
            SELECT 
                co.IdContract,
                cl.LastName AS LNameCl,
                cr.WIN_Number,
                cr.NameModel,
                sp.Price,
                co.ContractDate,
                co.IssueDate
            FROM Contract co
            INNER JOIN Car cr ON co.WIN_Number = cr.WIN_Number
            INNER JOIN Client cl ON cl.IdClient = co.IdClient
            INNER JOIN SalePrepairing sp ON co.WIN_Number = sp.WIN_Number AND co.IssueDate = sp.IssueDate
            INNER JOIN Dealer d ON d.IdDealer = sp.IdDealer
            WHERE d.Login = @login";

                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@login", login);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            contracts.Add(new MyContractDto
                            {
                                IdContract = reader.GetInt32(0),
                                LNameCl = reader.GetString(1),
                                WIN_Number = reader.GetString(2),
                                NameModel = reader.GetString(3),
                                Price = reader.GetDecimal(4),
                                ContractDate = reader.GetDateTime(5),
                                IssueDate = reader.GetDateTime(6)
                            });
                        }
                    }
                }
            }

            return contracts;
        }

    }
}
