﻿using Carmarket.API.CarService.Models;

namespace Carmarket.API.CarService.Services
{
    public interface ICarService
    {
        IEnumerable<Car> GetAllActiveCars();
        Car? GetByWin(string win);
        void Add(Car car, string dealerLogin); // ← додаємо логін дилера
        void UpdateStatus(string win, string status);
        byte[]? GetPhoto(string win);
        IEnumerable<CarDto> GetCarsByDealer(string login);
        void Delete(string win);
        void Update(CarUpdateDto dto);
        IEnumerable<CarDto> GetCarsByDealer(string login, string? search = null);


    }
}
