﻿using Carmarket.API.CarService.Models;

namespace Carmarket.API.CarService.Services
{
    public interface IContractService
    {
        IEnumerable<ContractDto> GetAll();
        void Delete(int id);
        IEnumerable<MyContractDto> GetByDealerLogin(string login);
    }
}

