﻿using Carmarket.API.CarService.Models;

namespace Carmarket.API.CarService.Services
{
    public interface IMarketService
    {
        IEnumerable<MarketCarDto> GetAllActiveForMarket();
        byte[]? GetPhoto(string win);
        void CreateContract(CreateContractDto dto);
    }
}
