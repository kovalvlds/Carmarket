﻿using Carmarket.API.CarService.Models;

namespace Carmarket.API.CarService.Services
{
    public interface ISaleService
    {
        IEnumerable<SaleDto> GetAll();
        SaleDto? GetLatestByWin(string win);
        void Add(AddSaleDto dto);
        void Delete(string win, string date);
    }
}

