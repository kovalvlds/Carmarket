﻿using Carmarket.API.CarService.Models;

namespace Carmarket.API.CarService.Services
{
    public interface IStatisticService
    {
        IEnumerable<MonthStatDto> GetContractsByMonth();
        IEnumerable<DealerEarningsDto> GetDealerEarnings();
        IEnumerable<ClientContractsDto> GetClientContractCounts();
    }
}

