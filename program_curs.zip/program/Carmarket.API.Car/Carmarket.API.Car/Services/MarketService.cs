﻿using Carmarket.API.CarService.Data;
using Carmarket.API.CarService.Models;
using System.Data.SqlClient;

namespace Carmarket.API.CarService.Services
{
    public class MarketService : IMarketService
    {
        private readonly DatabaseConnection _connection;

        public MarketService(DatabaseConnection connection)
        {
            _connection = connection;
        }

        public IEnumerable<MarketCarDto> GetAllActiveForMarket()
        {
            List<MarketCarDto> list = new();
            using var conn = _connection.GetConnection();
            conn.Open();

            string query = @"
            SELECT c.WIN_Number, c.Mileage, c.NameModel, m.Mark, c.TechnicalData,
                   c.ReleaseYear, sp.Price, sp.IssueDate
            FROM Car c
            INNER JOIN SalePrepairing sp ON sp.WIN_Number = c.WIN_Number
            INNER JOIN Model m ON c.NameModel = m.NameModel
            WHERE c.Status = 'активна' AND sp.IssueDate = (
                SELECT MAX(IssueDate)
                FROM SalePrepairing
                WHERE WIN_Number = sp.WIN_Number
            )";

            using SqlCommand cmd = new(query, conn);
            using SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new MarketCarDto
                {
                    WIN_Number = reader.GetString(0),
                    Mileage = reader.GetInt32(1),
                    NameModel = reader.GetString(2),
                    Mark = reader.GetString(3),
                    TechnicalData = reader.GetString(4),
                    ReleaseYear = reader.GetInt32(5),
                    Price = reader.GetDecimal(6),
                    IssueDate = reader.GetDateTime(7)
                });
            }
            return list;
        }

        public byte[]? GetPhoto(string win)
        {
            using var conn = _connection.GetConnection();
            conn.Open();

            var cmd = new SqlCommand("SELECT CarPhoto FROM Car WHERE WIN_Number = @win", conn);
            cmd.Parameters.AddWithValue("@win", win);

            using var reader = cmd.ExecuteReader();
            if (reader.Read() && reader["CarPhoto"] != DBNull.Value)
            {
                return (byte[])reader["CarPhoto"];
            }

            return null;
        }

        public void CreateContract(CreateContractDto dto)
        {
            using var conn = _connection.GetConnection();
            conn.Open();

            // отримати IdClient за логіном
            var getClientCmd = new SqlCommand("SELECT IdClient FROM Client WHERE Login = @login", conn);
            getClientCmd.Parameters.AddWithValue("@login", dto.Login);
            int clientId = (int)(getClientCmd.ExecuteScalar() ?? throw new Exception("Клієнт не знайдений"));

            // додати контракт
            var insertCmd = new SqlCommand(@"
            INSERT INTO Contract (ContractDate, IdClient, WIN_Number, IssueDate)
            VALUES (@date, @clientId, @win, @issue)", conn);

            insertCmd.Parameters.AddWithValue("@date", dto.ContractDate);
            insertCmd.Parameters.AddWithValue("@clientId", clientId);
            insertCmd.Parameters.AddWithValue("@win", dto.WIN_Number);
            insertCmd.Parameters.AddWithValue("@issue", dto.IssueDate);

            insertCmd.ExecuteNonQuery();

            // оновити статус авто
            var updateCmd = new SqlCommand("UPDATE Car SET Status = 'продана' WHERE WIN_Number = @win", conn);
            updateCmd.Parameters.AddWithValue("@win", dto.WIN_Number);
            updateCmd.ExecuteNonQuery();
        }
    }
}
