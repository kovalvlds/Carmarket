﻿using Carmarket.API.CarService.Data;
using Carmarket.API.CarService.Models;
using System.Data.SqlClient;

namespace Carmarket.API.CarService.Services
{
    public class SaleService : ISaleService
    {
        private readonly DatabaseConnection _db;

        public SaleService(DatabaseConnection db)
        {
            _db = db;
        }

        public IEnumerable<SaleDto> GetAll()
        {
            var sales = new List<SaleDto>();

            using var conn = _db.GetConnection();
            conn.Open();

            string query = @"
                SELECT sp.WIN_Number, sp.IssueDate, sp.IdDealer, sp.Price
                FROM SalePrepairing sp
                INNER JOIN Car c ON c.WIN_Number = sp.WIN_Number
                WHERE c.Status = 'активна'
                  AND sp.IssueDate = (
                      SELECT MAX(IssueDate)
                      FROM SalePrepairing
                      WHERE WIN_Number = sp.WIN_Number
                  )";

            using var cmd = new SqlCommand(query, conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                sales.Add(new SaleDto
                {
                    WIN_Number = reader.GetString(0),
                    IssueDate = reader.GetDateTime(1).ToString("yyyy-MM-dd"),
                    IdDealer = reader.GetInt32(2),
                    Price = reader.GetDecimal(3)
                });
            }

            return sales;
        }

        public SaleDto? GetLatestByWin(string win)
        {
            using var conn = _db.GetConnection();
            conn.Open();

            string query = @"
                SELECT TOP 1 WIN_Number, IssueDate, IdDealer, Price
                FROM SalePrepairing
                WHERE WIN_Number = @win
                ORDER BY IssueDate DESC";

            using var cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@win", win);

            using var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                return new SaleDto
                {
                    WIN_Number = reader.GetString(0),
                    IssueDate = reader.GetDateTime(1).ToString("yyyy-MM-dd"),
                    IdDealer = reader.GetInt32(2),
                    Price = reader.GetDecimal(3)
                };
            }

            return null;
        }

        public void Add(AddSaleDto dto)
        {
            using var conn = _db.GetConnection();
            conn.Open();

            // Додаємо у SalePrepairing
            string insertQuery = @"
                INSERT INTO SalePrepairing (WIN_Number, IssueDate, IdDealer, Price)
                SELECT @win, @date, IdDealer, @price
                FROM Dealer
                WHERE Login = @login";

            using var insertCmd = new SqlCommand(insertQuery, conn);
            insertCmd.Parameters.AddWithValue("@win", dto.WIN_Number);
            insertCmd.Parameters.AddWithValue("@date", dto.IssueDate);
            insertCmd.Parameters.AddWithValue("@price", dto.Price);
            insertCmd.Parameters.AddWithValue("@login", dto.Login);
            insertCmd.ExecuteNonQuery();

            // Оновлюємо статус авто
            string updateCar = "UPDATE Car SET Status = 'активна' WHERE WIN_Number = @win";
            using var updateCmd = new SqlCommand(updateCar, conn);
            updateCmd.Parameters.AddWithValue("@win", dto.WIN_Number);
            updateCmd.ExecuteNonQuery();
        }

        public void Delete(string win, string date)
        {
            using var conn = _db.GetConnection();
            conn.Open();

            // Видаляємо запис із SalePrepairing
            string deleteQuery = "DELETE FROM SalePrepairing WHERE WIN_Number = @win AND IssueDate = @date";
            using var deleteCmd = new SqlCommand(deleteQuery, conn);
            deleteCmd.Parameters.AddWithValue("@win", win);
            deleteCmd.Parameters.AddWithValue("@date", date);
            deleteCmd.ExecuteNonQuery();

            // Повертаємо статус авто
            string updateCar = "UPDATE Car SET Status = 'неактивна' WHERE WIN_Number = @win";
            using var updateCmd = new SqlCommand(updateCar, conn);
            updateCmd.Parameters.AddWithValue("@win", win);
            updateCmd.ExecuteNonQuery();
        }
    }
}
