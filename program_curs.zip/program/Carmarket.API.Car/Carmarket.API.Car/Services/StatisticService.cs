﻿using System.Data.SqlClient;
using Carmarket.API.CarService.Data;
using Carmarket.API.CarService.Models;

namespace Carmarket.API.CarService.Services
{
    public class StatisticService : IStatisticService
    {
        private readonly DatabaseConnection _db;

        public StatisticService(DatabaseConnection db)
        {
            _db = db;
        }

        public IEnumerable<MonthStatDto> GetContractsByMonth()
        {
            var list = new List<MonthStatDto>();

            using var conn = _db.GetConnection();
            conn.Open();

            string query = @"
                SELECT MONTH(ContractDate) AS Month, COUNT(IdContract) AS ContractCount
                FROM Contract
                GROUP BY MONTH(ContractDate)";

            using var cmd = new SqlCommand(query, conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new MonthStatDto
                {
                    Month = Convert.ToInt32(reader["Month"]),
                    ContractCount = Convert.ToInt32(reader["ContractCount"])
                });
            }

            return list;
        }

        public IEnumerable<DealerEarningsDto> GetDealerEarnings()
        {
            var list = new List<DealerEarningsDto>();

            using var conn = _db.GetConnection();
            conn.Open();

            string query = @"
                SELECT Dealer.IdDealer, SUM(Price) AS Earnings
                FROM SalePrepairing
                INNER JOIN Dealer ON SalePrepairing.IdDealer = Dealer.IdDealer
                WHERE EXISTS (
                    SELECT WIN_Number FROM Contract 
                    WHERE Contract.WIN_Number = SalePrepairing.WIN_Number
                )
                GROUP BY Dealer.IdDealer";

            using var cmd = new SqlCommand(query, conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new DealerEarningsDto
                {
                    IdDealer = Convert.ToInt32(reader["IdDealer"]),
                    Earnings = Convert.ToDecimal(reader["Earnings"])
                });
            }

            return list;
        }

        public IEnumerable<ClientContractsDto> GetClientContractCounts()
        {
            var list = new List<ClientContractsDto>();

            using var conn = _db.GetConnection();
            conn.Open();

            string query = @"
                SELECT IdClient, COUNT(*) AS ContractCount
                FROM Contract
                GROUP BY IdClient";

            using var cmd = new SqlCommand(query, conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new ClientContractsDto
                {
                    IdClient = Convert.ToInt32(reader["IdClient"]),
                    ContractCount = Convert.ToInt32(reader["ContractCount"])
                });
            }

            return list;
        }
    }
}
