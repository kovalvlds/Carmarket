﻿using System;
using System.Data.SqlClient;

namespace carmarcet
{
    class DataBase
    {
        private SqlConnection sqlConnection;

        public DataBase()
        {
            try
            {
                sqlConnection = new SqlConnection(@"Data Source=DESKTOP-H9M8CLD;Initial Catalog=CarMarket;Integrated Security=True");
            }
            catch (Exception ex)
            {
                // Логувати або пробросити далі, якщо потрібно
                Console.WriteLine("Помилка створення з'єднання: " + ex.Message);
            }
        }

        public void openConnection()
        {
            try
            {
                if (sqlConnection.State == System.Data.ConnectionState.Closed)
                {
                    sqlConnection.Open();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Не вдалося відкрити підключення до бази даних: " + ex.Message);
            }
        }

        public void closeConnection()
        {
            try
            {
                if (sqlConnection.State == System.Data.ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Помилка при закритті підключення: " + ex.Message);
            }
        }

        public SqlConnection getConnection()
        {
            return sqlConnection;
        }
    }
}
