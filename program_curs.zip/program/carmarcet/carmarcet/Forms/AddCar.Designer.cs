﻿namespace carmarcet
{
    partial class AddCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddCar));
            textBox_WIN = new TextBox();
            textBox_Mileage = new TextBox();
            textBox_TD = new TextBox();
            textBox_Model = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label5 = new Label();
            BtnSave = new PictureBox();
            label6 = new Label();
            BtnClear = new PictureBox();
            pictureBox1 = new PictureBox();
            BtnUpload = new Button();
            textBox_Year = new TextBox();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)BtnSave).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnClear).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // textBox_WIN
            // 
            textBox_WIN.BackColor = Color.LightYellow;
            textBox_WIN.Location = new Point(39, 91);
            textBox_WIN.Name = "textBox_WIN";
            textBox_WIN.Size = new Size(144, 23);
            textBox_WIN.TabIndex = 0;
            // 
            // textBox_Mileage
            // 
            textBox_Mileage.BackColor = Color.LightYellow;
            textBox_Mileage.Location = new Point(39, 157);
            textBox_Mileage.Name = "textBox_Mileage";
            textBox_Mileage.Size = new Size(144, 23);
            textBox_Mileage.TabIndex = 1;
            // 
            // textBox_TD
            // 
            textBox_TD.BackColor = Color.LightYellow;
            textBox_TD.Location = new Point(39, 280);
            textBox_TD.Multiline = true;
            textBox_TD.Name = "textBox_TD";
            textBox_TD.Size = new Size(143, 48);
            textBox_TD.TabIndex = 2;
            // 
            // textBox_Model
            // 
            textBox_Model.BackColor = Color.LightYellow;
            textBox_Model.Location = new Point(39, 223);
            textBox_Model.Name = "textBox_Model";
            textBox_Model.Size = new Size(144, 23);
            textBox_Model.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Bookman Old Style", 12F, FontStyle.Italic, GraphicsUnit.Point);
            label1.Location = new Point(63, 61);
            label1.Name = "label1";
            label1.Size = new Size(95, 18);
            label1.TabIndex = 6;
            label1.Text = "WIN номер";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Bookman Old Style", 12F, FontStyle.Italic, GraphicsUnit.Point);
            label2.Location = new Point(82, 136);
            label2.Name = "label2";
            label2.Size = new Size(60, 18);
            label2.TabIndex = 7;
            label2.Text = "Пробіг";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Bookman Old Style", 12F, FontStyle.Italic, GraphicsUnit.Point);
            label3.Location = new Point(82, 259);
            label3.Name = "label3";
            label3.Size = new Size(48, 18);
            label3.TabIndex = 8;
            label3.Text = "Опис";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Bookman Old Style", 12F, FontStyle.Italic, GraphicsUnit.Point);
            label5.Location = new Point(74, 202);
            label5.Name = "label5";
            label5.Size = new Size(68, 18);
            label5.TabIndex = 10;
            label5.Text = "Модель";
            // 
            // BtnSave
            // 
            BtnSave.Image = (Image)resources.GetObject("BtnSave.Image");
            BtnSave.Location = new Point(63, 407);
            BtnSave.Name = "BtnSave";
            BtnSave.Size = new Size(37, 33);
            BtnSave.SizeMode = PictureBoxSizeMode.StretchImage;
            BtnSave.TabIndex = 11;
            BtnSave.TabStop = false;
            BtnSave.Click += BtnSave_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Bookman Old Style", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(106, 9);
            label6.Name = "label6";
            label6.Size = new Size(357, 38);
            label6.TabIndex = 12;
            label6.Text = "Додати автомобіль";
            // 
            // BtnClear
            // 
            BtnClear.Image = (Image)resources.GetObject("BtnClear.Image");
            BtnClear.Location = new Point(12, 407);
            BtnClear.Name = "BtnClear";
            BtnClear.Size = new Size(39, 33);
            BtnClear.SizeMode = PictureBoxSizeMode.StretchImage;
            BtnClear.TabIndex = 13;
            BtnClear.TabStop = false;
            BtnClear.Click += BtnClear_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(239, 91);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(274, 237);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 14;
            pictureBox1.TabStop = false;
            // 
            // BtnUpload
            // 
            BtnUpload.BackColor = Color.ForestGreen;
            BtnUpload.FlatStyle = FlatStyle.Popup;
            BtnUpload.ForeColor = Color.White;
            BtnUpload.Location = new Point(261, 348);
            BtnUpload.Name = "BtnUpload";
            BtnUpload.Size = new Size(232, 24);
            BtnUpload.TabIndex = 15;
            BtnUpload.Text = "Завантажити фото";
            BtnUpload.UseVisualStyleBackColor = false;
            BtnUpload.Click += BtnUpload_Click_1;
            // 
            // textBox_Year
            // 
            textBox_Year.BackColor = Color.LightYellow;
            textBox_Year.Location = new Point(40, 369);
            textBox_Year.Name = "textBox_Year";
            textBox_Year.Size = new Size(143, 23);
            textBox_Year.TabIndex = 16;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Bookman Old Style", 12F, FontStyle.Italic, GraphicsUnit.Point);
            label4.Location = new Point(54, 348);
            label4.Name = "label4";
            label4.Size = new Size(104, 18);
            label4.TabIndex = 17;
            label4.Text = "Рік випуску";
            // 
            // AddCar
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.OldLace;
            ClientSize = new Size(559, 451);
            Controls.Add(label4);
            Controls.Add(textBox_Year);
            Controls.Add(BtnUpload);
            Controls.Add(pictureBox1);
            Controls.Add(BtnClear);
            Controls.Add(label6);
            Controls.Add(BtnSave);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBox_Model);
            Controls.Add(textBox_TD);
            Controls.Add(textBox_Mileage);
            Controls.Add(textBox_WIN);
            Name = "AddCar";
            Text = "AddCar";
            ((System.ComponentModel.ISupportInitialize)BtnSave).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnClear).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox_WIN;
        private TextBox textBox_Mileage;
        private TextBox textBox_TD;
        private TextBox textBox_Model;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label5;
        private PictureBox BtnSave;
        private Label label6;
        private PictureBox BtnClear;
        private PictureBox pictureBox1;
        private Button BtnUpload;
        private TextBox textBox_Year;
        private Label label4;
    }
}