﻿using System;
using System.IO;
using System.Drawing;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using carmarcet.Models;
using carmarcet.Services;
using carmarcet.Helpers;

namespace carmarcet
{
    public partial class AddCar : Form
    {
        private readonly CarApiClient carApiClient;
        private byte[]? photoData;
        private readonly string LOGIN;

        public AddCar(string login)
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            LOGIN = login;
            carApiClient = new CarApiClient("https://localhost:7072");
        }

        private void Clear()
        {
            textBox_WIN.Clear();
            textBox_Mileage.Clear();
            textBox_TD.Clear();
            textBox_Model.Clear();
            textBox_Year.Clear();
            pictureBox1.Image = null;
            photoData = null;
        }

        private async void BtnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (!int.TryParse(textBox_Mileage.Text, out int mileage) ||
                    !int.TryParse(textBox_Year.Text, out int year))
                {
                    MessageBox.Show("Невірно введено пробіг або рік випуску.");
                    return;
                }

                var car = new CarDto
                {
                    WIN_Number = textBox_WIN.Text,
                    Mileage = mileage,
                    TechnicalData = textBox_TD.Text,
                    NameModel = textBox_Model.Text,
                    ReleaseYear = year,
                    CarPhoto = photoData,
                    Status = "неактивна",
                    Login = LOGIN
                };

                var (success, error) = await carApiClient.AddCarAsync(car);

                if (success)
                {
                    MessageBox.Show("Авто успішно додано через API!");
                    Clear();
                }
                else
                {
                    MessageBox.Show("Помилка: " + error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Виняток: " + ex.Message);
            }
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void BtnUpload_Click_1(object sender, EventArgs e)
        {
            using OpenFileDialog openFileDialog = new();
            openFileDialog.Filter = "Зображення (*.jpg, *.jpeg, *.png)|*.jpg;*.jpeg;*.png";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                photoData = ImageHelper.LoadImageAsBytes(openFileDialog.FileName);
                pictureBox1.Image = ImageHelper.ConvertBytesToImage(photoData!);
            }
        }
    }
}
