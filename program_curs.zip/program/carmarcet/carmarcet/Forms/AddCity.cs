﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Forms;
using carmarcet.Services;

namespace carmarcet
{
    public partial class AddCity : Form
    {
        private readonly CityApiClient cityApiClient;
        private int selectedRow;

        public AddCity()
        {
            InitializeComponent();
            cityApiClient = new CityApiClient("https://localhost:7072");
            StartPosition = FormStartPosition.CenterScreen;
            CreateColumns();
            _ = RefreshDataGrid();
        }

        private void CreateColumns()
        {
            dataGridView1.Columns.Add("NameCity", "Місто");
        }

        private void ReadSingleRow(string nameCity)
        {
            dataGridView1.Rows.Add(nameCity);
        }

        private async Task RefreshDataGrid()
        {
            dataGridView1.Rows.Clear();
            var cities = await cityApiClient.GetAllCitiesAsync();

            if (cities == null)
            {
                MessageBox.Show("Не вдалося отримати список міст.");
                return;
            }

            foreach (var city in cities)
                ReadSingleRow(city);

            Clear();
        }

        private async void button1_Click_1(object sender, EventArgs e)
        {
            string city = textBox_City.Text.Trim();
            if (string.IsNullOrWhiteSpace(city)) return;

            bool success = await cityApiClient.AddCityAsync(city);

            MessageBox.Show(success ? "Місто успішно додано" : "Помилка при додаванні міста");
            if (success) await RefreshDataGrid();
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            string city = textBox_City.Text.Trim();
            if (string.IsNullOrWhiteSpace(city)) return;

            bool success = await cityApiClient.DeleteCityAsync(city);

            MessageBox.Show(success ? "Місто успішно видалено" : "Помилка при видаленні міста");
            if (success) await RefreshDataGrid();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            selectedRow = e.RowIndex;
            textBox_City.Text = dataGridView1.Rows[selectedRow].Cells[0].Value?.ToString();
        }

        private void Clear()
        {
            textBox_City.Clear();
        }
    }
}
