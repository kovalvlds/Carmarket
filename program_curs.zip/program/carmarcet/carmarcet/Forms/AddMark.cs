﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Forms;
using carmarcet.Services;

namespace carmarcet
{
    public partial class AddMark : Form
    {
        private readonly MarkApiClient markApiClient;
        private int selectedRow;

        public AddMark()
        {
            InitializeComponent();
            markApiClient = new MarkApiClient("https://localhost:7072");
            StartPosition = FormStartPosition.CenterScreen;
            CreateColumns();
            _ = RefreshDataGrid();
        }

        private void CreateColumns()
        {
            dataGridView1.Columns.Add("Mark", "Марка");
        }

        private void ReadSingleRow(string mark)
        {
            dataGridView1.Rows.Add(mark);
        }

        private async Task RefreshDataGrid()
        {
            dataGridView1.Rows.Clear();
            var marks = await markApiClient.GetAllMarksAsync();

            if (marks == null)
            {
                MessageBox.Show("Не вдалося отримати список марок.");
                return;
            }

            foreach (var mark in marks)
                ReadSingleRow(mark);

            Clear();
        }

        private async void button_Add_Click(object sender, EventArgs e)
        {
            var mark = textBox_Mark.Text.Trim();
            if (string.IsNullOrWhiteSpace(mark)) return;

            bool success = await markApiClient.AddMarkAsync(mark);
            MessageBox.Show(success ? "Марку успішно додано" : "Помилка при додаванні марки");
            if (success) await RefreshDataGrid();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            var mark = textBox_Mark.Text.Trim();
            if (string.IsNullOrWhiteSpace(mark)) return;

            bool success = await markApiClient.DeleteMarkAsync(mark);
            MessageBox.Show(success ? "Марку успішно видалено" : "Помилка при видаленні марки");
            if (success) await RefreshDataGrid();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            selectedRow = e.RowIndex;
            textBox_Mark.Text = dataGridView1.Rows[selectedRow].Cells[0].Value?.ToString();
        }

        private void Clear()
        {
            textBox_Mark.Clear();
        }
    }
}
