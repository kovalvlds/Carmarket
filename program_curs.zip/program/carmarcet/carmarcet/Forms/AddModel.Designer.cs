﻿namespace carmarcet
{
    partial class AddModel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            label1 = new Label();
            textBox_Model = new TextBox();
            textBox_Mark = new TextBox();
            button_Delete = new Button();
            button_Add = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 23);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(264, 415);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Bookman Old Style", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(346, 23);
            label1.Name = "label1";
            label1.Size = new Size(85, 22);
            label1.TabIndex = 1;
            label1.Text = "Модель";
            // 
            // textBox_Model
            // 
            textBox_Model.Location = new Point(346, 97);
            textBox_Model.Name = "textBox_Model";
            textBox_Model.Size = new Size(85, 23);
            textBox_Model.TabIndex = 2;
            // 
            // textBox_Mark
            // 
            textBox_Mark.Location = new Point(346, 58);
            textBox_Mark.Name = "textBox_Mark";
            textBox_Mark.Size = new Size(85, 23);
            textBox_Mark.TabIndex = 3;
            // 
            // button_Delete
            // 
            button_Delete.Location = new Point(346, 162);
            button_Delete.Name = "button_Delete";
            button_Delete.Size = new Size(85, 23);
            button_Delete.TabIndex = 7;
            button_Delete.Text = "Видалити";
            button_Delete.UseVisualStyleBackColor = true;
            button_Delete.Click += button_Delete_Click;
            // 
            // button_Add
            // 
            button_Add.Location = new Point(346, 133);
            button_Add.Name = "button_Add";
            button_Add.Size = new Size(85, 23);
            button_Add.TabIndex = 6;
            button_Add.Text = "Додати";
            button_Add.UseVisualStyleBackColor = true;
            button_Add.Click += button_Add_Click;
            // 
            // AddModel
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(472, 450);
            Controls.Add(button_Delete);
            Controls.Add(button_Add);
            Controls.Add(textBox_Mark);
            Controls.Add(textBox_Model);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Name = "AddModel";
            Text = "AddModel";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Label label1;
        private TextBox textBox_Model;
        private TextBox textBox_Mark;
        private Button button_Delete;
        private Button button_Add;
    }
}