﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Forms;
using carmarcet.Models;
using carmarcet.Services;

namespace carmarcet
{
    public partial class AddModel : Form
    {
        private readonly ModelApiClient modelApiClient;
        private int selectedRow;

        public AddModel()
        {
            InitializeComponent();
            modelApiClient = new ModelApiClient("https://localhost:7072");
            StartPosition = FormStartPosition.CenterScreen;
            CreateColumns();
            _ = RefreshDataGrid();
        }

        private void CreateColumns()
        {
            dataGridView1.Columns.Add("NameModel", "Модель");
            dataGridView1.Columns.Add("Mark", "Марка");
        }

        private void ReadSingleRow(ModelDto model)
        {
            dataGridView1.Rows.Add(model.NameModel, model.Mark);
        }

        private async Task RefreshDataGrid()
        {
            dataGridView1.Rows.Clear();
            var models = await modelApiClient.GetAllModelsAsync();

            if (models == null)
            {
                MessageBox.Show("Не вдалося отримати список моделей.");
                return;
            }

            foreach (var model in models)
                ReadSingleRow(model);

            Clear();
        }

        private async void button_Add_Click(object sender, EventArgs e)
        {
            var nameModel = textBox_Model.Text.Trim();
            var mark = textBox_Mark.Text.Trim();

            if (string.IsNullOrWhiteSpace(nameModel) || string.IsNullOrWhiteSpace(mark))
            {
                MessageBox.Show("Введіть і модель, і марку.");
                return;
            }

            var model = new ModelDto { NameModel = nameModel, Mark = mark };
            bool success = await modelApiClient.AddModelAsync(model);

            MessageBox.Show(success ? "Модель успішно додано" : "Помилка при додаванні моделі");
            if (success) await RefreshDataGrid();
        }

        private async void button_Delete_Click(object sender, EventArgs e)
        {
            var nameModel = textBox_Model.Text.Trim();
            if (string.IsNullOrWhiteSpace(nameModel)) return;

            bool success = await modelApiClient.DeleteModelAsync(nameModel);

            MessageBox.Show(success ? "Модель успішно видалено" : "Помилка при видаленні моделі");
            if (success) await RefreshDataGrid();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            selectedRow = e.RowIndex;
            var row = dataGridView1.Rows[selectedRow];
            textBox_Model.Text = row.Cells[0].Value?.ToString();
            textBox_Mark.Text = row.Cells[1].Value?.ToString();
        }

        private void Clear()
        {
            textBox_Model.Clear();
            textBox_Mark.Clear();
        }
    }
}
