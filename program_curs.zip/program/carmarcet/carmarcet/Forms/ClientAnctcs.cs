﻿using System;
using System.Windows.Forms;
using carmarcet.Models;
using carmarcet.Services;

namespace carmarcet
{
    public partial class ClientAnctcs : Form
    {
        private readonly ClientApiClient clientApiClient;

        public ClientAnctcs(string login)
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            textBox_Login.Text = login;
            textBox_Login.ReadOnly = true;

            clientApiClient = new ClientApiClient("https://localhost:7072");
        }

        private async void button_Enter_Click(object sender, EventArgs e)
        {
            var dto = new ClientDto
            {
                LastName = textBox_LName.Text.Trim(),
                Name = textBox_Name.Text.Trim(),
                MiddleName = textBox_MName.Text.Trim(),
                Address = textBox_Adress.Text.Trim(),
                Email = textBox_Email.Text.Trim(),
                Login = textBox_Login.Text.Trim(),
                NameCity = textBox_City.Text.Trim(),
                ClientPhone = textBox_Phone.Text.Trim()
            };

            try
            {
                var (success, message) = await clientApiClient.SubmitProfileAsync(dto);

                if (success)
                {
                    MessageBox.Show("Анкету успішно заповнено", "Успіх!");
                    Hide();
                    new Login().ShowDialog();
                    Close();
                }
                else
                {
                    MessageBox.Show("Помилка: " + message);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Анкету не створено (помилка): {ex.Message}");
            }
        }
    }
}
