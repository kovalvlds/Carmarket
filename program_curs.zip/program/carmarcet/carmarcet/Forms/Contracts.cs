﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Forms;
using carmarcet.Models;
using carmarcet.Services;

namespace carmarcet
{
    public partial class Contracts : Form
    {
        private readonly ContractApiClient contractApiClient;
        private int selectedRow;

        public Contracts()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            contractApiClient = new ContractApiClient("https://localhost:7072");
        }

        private async void Contracts_Load(object sender, EventArgs e)
        {
            CreateColumns();
            await RefreshDataGridAsync();
        }

        private void CreateColumns()
        {
            dataGridView1.Columns.Add("IdContract", "ІН_контракт");
            dataGridView1.Columns.Add("ContractDate", "Дата заключення");
            dataGridView1.Columns.Add("IdClient", "ІН_клієнта");
            dataGridView1.Columns.Add("WIN_Number", "WIN_Number");
            dataGridView1.Columns.Add("IssueDate", "Дата виставлення");
        }

        private async Task RefreshDataGridAsync()
        {
            dataGridView1.Rows.Clear();
            try
            {
                var contracts = await contractApiClient.GetAllContractsAsync();
                if (contracts == null)
                {
                    MessageBox.Show("Не вдалося отримати список контрактів.");
                    return;
                }

                foreach (var c in contracts)
                {
                    dataGridView1.Rows.Add(c.IdContract, c.ContractDate.ToShortDateString(), c.IdClient, c.WIN_Number, c.IssueDate.ToShortDateString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при завантаженні контрактів: " + ex.Message);
            }
        }

        private async void pictureBox1_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(textBox_id.Text, out int id))
            {
                MessageBox.Show("Невірний формат ID контракту");
                return;
            }

            try
            {
                bool success = await contractApiClient.DeleteContractAsync(id);
                if (success)
                {
                    MessageBox.Show("Контракт видалено");
                    await RefreshDataGridAsync();
                }
                else
                {
                    MessageBox.Show("Помилка при видаленні контракту");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при видаленні: " + ex.Message);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            selectedRow = e.RowIndex;
            var row = dataGridView1.Rows[selectedRow];
            textBox_id.Text = row.Cells[0].Value?.ToString();
        }
    }
}
