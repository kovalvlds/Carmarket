﻿using System;
using System.Windows.Forms;
using carmarcet.Models;
using carmarcet.Services;

namespace carmarcet
{
    public partial class DealerAnctcs : Form
    {
        private readonly DealerApiClient dealerApiClient;

        public DealerAnctcs(string login)
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            textBox_login.Text = login;
            textBox_login.ReadOnly = true;

            dealerApiClient = new DealerApiClient("https://localhost:7072");
        }

        private async void button_Enter_Click(object sender, EventArgs e)
        {
            var dto = new DealerDto
            {
                LastName = textBox_LName.Text.Trim(),
                Name = textBox_Name.Text.Trim(),
                MiddleName = textBox_MName.Text.Trim(),
                HomeAdress = textBox_Adress.Text.Trim(),
                Login = textBox_login.Text.Trim(),
                DealerPhone = textBox_Phone.Text.Trim()
            };

            try
            {
                var (success, message) = await dealerApiClient.SubmitProfileAsync(dto);

                if (success)
                {
                    MessageBox.Show("Анкету успішно заповнено", "Успіх!");
                    Hide();
                    new Login().ShowDialog();
                    Close();
                }
                else
                {
                    MessageBox.Show("Помилка: " + message);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Анкету не створено (помилка): {ex.Message}");
            }
        }
    }
}
