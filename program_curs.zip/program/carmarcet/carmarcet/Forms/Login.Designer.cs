﻿namespace carmarcet
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            label1 = new Label();
            textBox_login = new TextBox();
            textBox_password = new TextBox();
            button_login = new Button();
            label2 = new Label();
            Btn_Clear = new PictureBox();
            BtnManager = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)Btn_Clear).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnManager).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Bookman Old Style", 26.25F, FontStyle.Bold);
            label1.Location = new Point(81, 9);
            label1.Name = "label1";
            label1.Size = new Size(257, 41);
            label1.TabIndex = 0;
            label1.Text = "Авторизація";
            // 
            // textBox_login
            // 
            textBox_login.Location = new Point(81, 89);
            textBox_login.Name = "textBox_login";
            textBox_login.Size = new Size(257, 23);
            textBox_login.TabIndex = 1;
            // 
            // textBox_password
            // 
            textBox_password.Location = new Point(81, 145);
            textBox_password.Name = "textBox_password";
            textBox_password.Size = new Size(257, 23);
            textBox_password.TabIndex = 2;
            // 
            // button_login
            // 
            button_login.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold);
            button_login.Location = new Point(152, 204);
            button_login.Name = "button_login";
            button_login.Size = new Size(111, 41);
            button_login.TabIndex = 3;
            button_login.Text = "Увійти";
            button_login.UseVisualStyleBackColor = true;
            button_login.Click += button_login_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Historic", 11.25F, FontStyle.Bold | FontStyle.Underline);
            label2.Location = new Point(100, 303);
            label2.Name = "label2";
            label2.Size = new Size(202, 20);
            label2.TabIndex = 4;
            label2.Text = "Ще не зареєструвалися?";
            label2.Click += label2_Click;
            // 
            // Btn_Clear
            // 
            Btn_Clear.Image = (Image)resources.GetObject("Btn_Clear.Image");
            Btn_Clear.Location = new Point(366, 108);
            Btn_Clear.Name = "Btn_Clear";
            Btn_Clear.Size = new Size(35, 35);
            Btn_Clear.SizeMode = PictureBoxSizeMode.StretchImage;
            Btn_Clear.TabIndex = 5;
            Btn_Clear.TabStop = false;
            Btn_Clear.Click += Btn_Clear_Click;
            // 
            // BtnManager
            // 
            BtnManager.Image = (Image)resources.GetObject("BtnManager.Image");
            BtnManager.Location = new Point(382, 312);
            BtnManager.Name = "BtnManager";
            BtnManager.Size = new Size(40, 37);
            BtnManager.SizeMode = PictureBoxSizeMode.StretchImage;
            BtnManager.TabIndex = 8;
            BtnManager.TabStop = false;
            BtnManager.Click += BtnManager_Click;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(434, 361);
            Controls.Add(BtnManager);
            Controls.Add(Btn_Clear);
            Controls.Add(label2);
            Controls.Add(button_login);
            Controls.Add(textBox_password);
            Controls.Add(textBox_login);
            Controls.Add(label1);
            Name = "Login";
            Text = "Login";
            Load += Login_Load;
            ((System.ComponentModel.ISupportInitialize)Btn_Clear).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnManager).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBox_login;
        private TextBox textBox_password;
        private Button button_login;
        private Label label2;
        private PictureBox Btn_Clear;
        private PictureBox BtnManager;
    }
}