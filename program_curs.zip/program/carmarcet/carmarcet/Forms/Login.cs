﻿using System;
using System.Windows.Forms;
using carmarcet.Models;
using carmarcet.Services;

namespace carmarcet
{
    public partial class Login : Form
    {
        private readonly AuthApiClient authApiClient;
        private string LOGIN;

        public Login()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            authApiClient = new AuthApiClient("https://localhost:7072");
        }

        private void Login_Load(object sender, EventArgs e)
        {
            textBox_password.PasswordChar = '*';
        }

        private async void button_login_Click(object sender, EventArgs e)
        {
            var loginUser = textBox_login.Text.Trim();
            var passwordUser = textBox_password.Text.Trim();

            var dto = new AuthLoginDto
            {
                Login = loginUser,
                Password = passwordUser
            };

            try
            {
                var result = await authApiClient.LoginAsync(dto);

                if (result != null && result.Role != null)
                {
                    MessageBox.Show(result.Message, "Успішно!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LOGIN = loginUser;

                    Form nextForm = result.Role switch
                    {
                        "client" => new Market(LOGIN),
                        "dealer" => new Place(LOGIN),
                        _ => null
                    };

                    if (nextForm != null)
                    {
                        Hide();
                        nextForm.ShowDialog();
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("Невідома роль: " + result.Role);
                    }
                }
                else
                {
                    MessageBox.Show(result?.Message ?? "Помилка входу", "Помилка!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка підключення до API: " + ex.Message);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Hide();
            new Singup().ShowDialog();
            Show();
        }

        private void Btn_Clear_Click(object sender, EventArgs e)
        {
            textBox_login.Clear();
            textBox_password.Clear();
        }

        private void BtnManager_Click(object sender, EventArgs e)
        {
            if (textBox_login.Text == "manager" && textBox_password.Text == "manager")
            {
                Hide();
                new ManagerMenu().ShowDialog();
                Close();
            }
            else
            {
                MessageBox.Show("Ви не менеджер");
            }
        }
    }
}
