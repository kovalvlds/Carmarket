﻿namespace carmarcet
{
    partial class ManagerMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            dataGridView2 = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            menuStrip1 = new MenuStrip();
            AddMarkMS = new ToolStripMenuItem();
            AddModelMS = new ToolStripMenuItem();
            AddCityMS = new ToolStripMenuItem();
            AddContractsMS = new ToolStripMenuItem();
            AddStatisticMS = new ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 134);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(640, 271);
            dataGridView1.TabIndex = 0;
            // 
            // dataGridView2
            // 
            dataGridView2.AllowUserToAddRows = false;
            dataGridView2.AllowUserToDeleteRows = false;
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(670, 134);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.ReadOnly = true;
            dataGridView2.RowTemplate.Height = 25;
            dataGridView2.Size = new Size(644, 271);
            dataGridView2.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Bookman Old Style", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(12, 93);
            label1.Name = "label1";
            label1.Size = new Size(168, 38);
            label1.TabIndex = 2;
            label1.Text = "Клієнти:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Bookman Old Style", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(670, 93);
            label2.Name = "label2";
            label2.Size = new Size(176, 38);
            label2.TabIndex = 3;
            label2.Text = "Диллери:";
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { AddMarkMS, AddModelMS, AddCityMS, AddContractsMS, AddStatisticMS });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1326, 24);
            menuStrip1.TabIndex = 4;
            menuStrip1.Text = "menuStrip1";
            // 
            // AddMarkMS
            // 
            AddMarkMS.Name = "AddMarkMS";
            AddMarkMS.Size = new Size(95, 20);
            AddMarkMS.Text = "Додати марку";
            AddMarkMS.Click += AddMarkMS_Click;
            // 
            // AddModelMS
            // 
            AddModelMS.Name = "AddModelMS";
            AddModelMS.Size = new Size(102, 20);
            AddModelMS.Text = "Додати модель";
            AddModelMS.Click += AddModelMS_Click;
            // 
            // AddCityMS
            // 
            AddCityMS.Name = "AddCityMS";
            AddCityMS.Size = new Size(91, 20);
            AddCityMS.Text = "Додати місто";
            AddCityMS.Click += AddCityMS_Click;
            // 
            // AddContractsMS
            // 
            AddContractsMS.Name = "AddContractsMS";
            AddContractsMS.Size = new Size(76, 20);
            AddContractsMS.Text = "Контракти";
            AddContractsMS.Click += AddContractsMS_Click;
            // 
            // AddStatisticMS
            // 
            AddStatisticMS.Name = "AddStatisticMS";
            AddStatisticMS.Size = new Size(80, 20);
            AddStatisticMS.Text = "Статистика";
            AddStatisticMS.Click += AddStatisticMS_Click;
            // 
            // ManagerMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1326, 419);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dataGridView2);
            Controls.Add(dataGridView1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "ManagerMenu";
            Text = "ManagerMenu";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private DataGridView dataGridView2;
        private Label label1;
        private Label label2;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem AddMarkMS;
        private ToolStripMenuItem AddModelMS;
        private ToolStripMenuItem AddCityMS;
        private ToolStripMenuItem AddContractsMS;
        private ToolStripMenuItem AddStatisticMS;
    }
}