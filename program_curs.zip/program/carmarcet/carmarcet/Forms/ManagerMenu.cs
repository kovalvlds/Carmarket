﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Forms;
using carmarcet.Models;
using carmarcet.Services;

namespace carmarcet
{
    public partial class ManagerMenu : Form
    {
        private readonly ClientApiClient clientApiClient;
        private readonly DealerApiClient dealerApiClient;

        public ManagerMenu()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            clientApiClient = new ClientApiClient("https://localhost:7072");
            dealerApiClient = new DealerApiClient("https://localhost:7072");

            CreateColumnsClient();
            CreateColumnsDealer();

            _ = RefreshDataGridClientAsync();
            _ = RefreshDataGridDealerAsync();
        }

        private void CreateColumnsClient()
        {
            dataGridView1.Columns.Clear();
            dataGridView1.Columns.Add("IdClient", "ІН_номер");
            dataGridView1.Columns.Add("LastName", "Прізвище");
            dataGridView1.Columns.Add("Name", "Ім'я");
            dataGridView1.Columns.Add("MiddleName", "Побатькові");
            dataGridView1.Columns.Add("Address", "Адреса");
            dataGridView1.Columns.Add("Email", "Email");
            dataGridView1.Columns.Add("Login", "Логін");
            dataGridView1.Columns.Add("NameCity", "Місто");
            dataGridView1.Columns.Add("ClientPhone", "Телефон");
        }

        private void CreateColumnsDealer()
        {
            dataGridView2.Columns.Clear();
            dataGridView2.Columns.Add("IdDealer", "ІН_номер");
            dataGridView2.Columns.Add("LastName", "Прізвище");
            dataGridView2.Columns.Add("Name", "Ім'я");
            dataGridView2.Columns.Add("MiddleName", "Побатькові");
            dataGridView2.Columns.Add("HomeAdress", "Адреса");
            dataGridView2.Columns.Add("Login", "Логін");
            dataGridView2.Columns.Add("DealerPhone", "Телефон");
        }

        private async Task RefreshDataGridClientAsync()
        {
            dataGridView1.Rows.Clear();

            try
            {
                var clients = await clientApiClient.GetAllClientsAsync();
                if (clients == null)
                {
                    MessageBox.Show("Не вдалося отримати клієнтів.");
                    return;
                }

                foreach (var c in clients)
                {
                    dataGridView1.Rows.Add(
                        c.IdClient, c.LastName, c.Name, c.MiddleName,
                        c.Address, c.Email, c.Login, c.NameCity, c.ClientPhone
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при завантаженні клієнтів: " + ex.Message);
            }
        }

        private async Task RefreshDataGridDealerAsync()
        {
            dataGridView2.Rows.Clear();

            try
            {
                var dealers = await dealerApiClient.GetAllDealersAsync();
                if (dealers == null)
                {
                    MessageBox.Show("Не вдалося отримати дилерів.");
                    return;
                }

                foreach (var d in dealers)
                {
                    dataGridView2.Rows.Add(
                        d.IdDealer, d.LastName, d.Name, d.MiddleName,
                        d.HomeAdress, d.Login, d.DealerPhone
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при завантаженні дилерів: " + ex.Message);
            }
        }

        // Меню-кнопки
        private void AddMarkMS_Click(object sender, EventArgs e) => ShowForm(new AddMark());
        private void AddModelMS_Click(object sender, EventArgs e) => ShowForm(new AddModel());
        private void AddCityMS_Click(object sender, EventArgs e) => ShowForm(new AddCity());
        private void AddStatisticMS_Click(object sender, EventArgs e) => ShowForm(new Statistic());
        private void AddContractsMS_Click(object sender, EventArgs e) => ShowForm(new Contracts());

        private void ShowForm(Form form)
        {
            Hide();
            form.ShowDialog();
            Show();
        }
    }
}
