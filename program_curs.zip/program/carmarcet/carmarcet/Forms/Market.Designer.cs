﻿namespace carmarcet
{
    partial class Market
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            BtnBuy = new Button();
            textBox_WIN = new TextBox();
            label1 = new Label();
            label2 = new Label();
            textBox_Login = new TextBox();
            label4 = new Label();
            textBox1 = new TextBox();
            pictureBox1 = new PictureBox();
            dateTimePickerContract = new DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.BackgroundColor = Color.LightYellow;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 12);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.Size = new Size(873, 254);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // BtnBuy
            // 
            BtnBuy.FlatStyle = FlatStyle.Popup;
            BtnBuy.Font = new Font("Bookman Old Style", 12F, FontStyle.Bold);
            BtnBuy.Location = new Point(799, 362);
            BtnBuy.Name = "BtnBuy";
            BtnBuy.Size = new Size(86, 75);
            BtnBuy.TabIndex = 1;
            BtnBuy.Text = "Купити";
            BtnBuy.UseVisualStyleBackColor = true;
            BtnBuy.Click += BtnBuy_Click;
            // 
            // textBox_WIN
            // 
            textBox_WIN.BackColor = Color.LightYellow;
            textBox_WIN.Location = new Point(625, 306);
            textBox_WIN.Name = "textBox_WIN";
            textBox_WIN.ReadOnly = true;
            textBox_WIN.Size = new Size(150, 23);
            textBox_WIN.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Bookman Old Style", 14.25F, FontStyle.Bold);
            label1.Location = new Point(500, 307);
            label1.Name = "label1";
            label1.Size = new Size(119, 22);
            label1.TabIndex = 4;
            label1.Text = "WIN номер";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Bookman Old Style", 14.25F, FontStyle.Bold);
            label2.Location = new Point(442, 364);
            label2.Name = "label2";
            label2.Size = new Size(177, 22);
            label2.TabIndex = 5;
            label2.Text = "Дата придбання";
            // 
            // textBox_Login
            // 
            textBox_Login.BackColor = Color.LightYellow;
            textBox_Login.Location = new Point(625, 414);
            textBox_Login.Name = "textBox_Login";
            textBox_Login.ReadOnly = true;
            textBox_Login.Size = new Size(150, 23);
            textBox_Login.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Bookman Old Style", 14.25F, FontStyle.Bold);
            label4.Location = new Point(507, 415);
            label4.Name = "label4";
            label4.Size = new Size(112, 22);
            label4.TabIndex = 8;
            label4.Text = "Ваш логін";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(799, 302);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(76, 23);
            textBox1.TabIndex = 9;
            textBox1.Visible = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(12, 272);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(225, 180);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            // 
            // dateTimePickerContract
            // 
            dateTimePickerContract.Location = new Point(625, 362);
            dateTimePickerContract.Name = "dateTimePickerContract";
            dateTimePickerContract.Size = new Size(150, 23);
            dateTimePickerContract.TabIndex = 12;
            // 
            // Market
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.OldLace;
            ClientSize = new Size(897, 464);
            Controls.Add(dateTimePickerContract);
            Controls.Add(pictureBox1);
            Controls.Add(textBox1);
            Controls.Add(label4);
            Controls.Add(textBox_Login);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBox_WIN);
            Controls.Add(BtnBuy);
            Controls.Add(dataGridView1);
            Name = "Market";
            Text = "Market";
            Load += Market_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Button BtnBuy;
        private TextBox textBox_WIN;
        private Label label1;
        private Label label2;
        private TextBox textBox_Login;
        private Label label4;
        private TextBox textBox1;
        private PictureBox pictureBox1;
        private DateTimePicker dateTimePickerContract;
    }
}