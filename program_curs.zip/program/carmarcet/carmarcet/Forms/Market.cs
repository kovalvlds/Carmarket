﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using carmarcet.Models;
using carmarcet.Services;

namespace carmarcet
{
    public partial class Market : Form
    {
        private readonly MarketApiClient marketApiClient;
        private int selectedRow;
        private readonly string LOGIN;

        public Market(string login)
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            LOGIN = login;
            marketApiClient = new MarketApiClient("https://localhost:7072");
        }

        private async void Market_Load(object sender, EventArgs e)
        {
            CreateColumns();
            await LoadCarsAsync();
            textBox_Login.Text = LOGIN;
            dateTimePickerContract.Format = DateTimePickerFormat.Custom;
            dateTimePickerContract.CustomFormat = "yyyy-MM-dd";
            dateTimePickerContract.Value = DateTime.Today;
        }

        private void CreateColumns()
        {
            dataGridView1.Columns.Add("WIN_Number", "WIN_Number");
            dataGridView1.Columns.Add("Mileage", "Пробіг");
            dataGridView1.Columns.Add("NameModel", "Модель");
            dataGridView1.Columns.Add("Mark", "Марка");
            dataGridView1.Columns.Add("TechnicalData", "Опис");
            dataGridView1.Columns.Add("ReleaseYear", "Рік випуску");
            dataGridView1.Columns.Add("Price", "Ціна");
            dataGridView1.Columns.Add("IssueDate", "Дата оголошення");
        }

        private async Task LoadCarsAsync()
        {
            dataGridView1.Rows.Clear();
            var cars = await marketApiClient.GetAvailableCarsAsync();

            if (cars == null)
            {
                MessageBox.Show("Не вдалося завантажити авто.");
                return;
            }

            foreach (var car in cars)
            {
                dataGridView1.Rows.Add(car.WIN_Number, car.Mileage, car.NameModel, car.Mark, car.TechnicalData, car.ReleaseYear, car.Price, car.IssueDate);
            }
        }

        private async void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;
            if (e.RowIndex < 0) return;

            var row = dataGridView1.Rows[selectedRow];
            textBox_WIN.Text = row.Cells[0].Value?.ToString();
            textBox1.Text = row.Cells[7].Value?.ToString();

            var photo = await marketApiClient.GetCarPhotoAsync(textBox_WIN.Text);
            pictureBox1.Image = photo != null ? ByteArrayToBitmap(photo) : null;
        }

        private Bitmap ByteArrayToBitmap(byte[] byteArray)
        {
            using MemoryStream stream = new MemoryStream(byteArray);
            return new Bitmap(stream);
        }

        private async void BtnBuy_Click(object sender, EventArgs e)
        {
            var dto = new BuyContractDto
            {
                WIN_Number = textBox_WIN.Text,
                Login = LOGIN,
                ContractDate = dateTimePickerContract.Value.ToString("yyyy-MM-dd"),
                IssueDate = textBox1.Text
            };

            var (success, message) = await marketApiClient.BuyCarAsync(dto);

            if (success)
            {
                MessageBox.Show("Контракт успішно підписаний", "Успіх");
                await LoadCarsAsync();
            }
            else
            {
                MessageBox.Show("Помилка покупки: " + message);
            }
        }
    }
}
