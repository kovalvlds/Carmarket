﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Forms;
using carmarcet.Models;
using carmarcet.Services;

namespace carmarcet
{
    public partial class MyContracts : Form
    {
        private readonly string LOGIN;
        private readonly ContractApiClient contractApiClient;

        public MyContracts(string login)
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            LOGIN = login;
            contractApiClient = new ContractApiClient("https://localhost:7072");
        }

        private async void MyContracts_Load(object sender, EventArgs e)
        {
            CreateColumns();
            await LoadContractsAsync();
        }

        private void CreateColumns()
        {
            dataGridView1.Columns.Clear();
            dataGridView1.Columns.Add("IdContract", "ІН_контракт");
            dataGridView1.Columns.Add("LNameCl", "Прізвище_клієнта");
            dataGridView1.Columns.Add("WIN_Number", "WIN_Number");
            dataGridView1.Columns.Add("NameModel", "Модель");
            dataGridView1.Columns.Add("Price", "Ціна");
            dataGridView1.Columns.Add("ContractDate", "ДатаПродаж");
            dataGridView1.Columns.Add("IssueDate", "ДатаВиставленняНаПродаж");
        }

        private async Task LoadContractsAsync()
        {
            dataGridView1.Rows.Clear();

            try
            {
                var contracts = await contractApiClient.GetContractsByDealerLoginAsync(LOGIN);

                if (contracts == null)
                {
                    MessageBox.Show("Контракти не знайдено або сталася помилка.");
                    return;
                }

                foreach (var c in contracts)
                {
                    dataGridView1.Rows.Add(c.IdContract, c.LNameCl, c.WIN_Number, c.NameModel, c.Price, c.ContractDate, c.IssueDate);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при завантаженні контрактів: " + ex.Message);
            }
        }
    }
}
