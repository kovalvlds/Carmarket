﻿namespace carmarcet
{
    partial class Place
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Place));
            dataGridView1 = new DataGridView();
            textBox_Win = new TextBox();
            textBox_Mileage = new TextBox();
            textBox_TD = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            BtnRefresh = new PictureBox();
            textBox_Status = new TextBox();
            label4 = new Label();
            textBox_Search = new TextBox();
            label5 = new Label();
            BtnSave = new PictureBox();
            BtnDelete = new PictureBox();
            BtnChange = new Button();
            menuStrip1 = new MenuStrip();
            AddAutoSM = new ToolStripMenuItem();
            OnBaseSM = new ToolStripMenuItem();
            SaleCarSM = new ToolStripMenuItem();
            BtnStaticric = new ToolStripMenuItem();
            MyContractsSM = new ToolStripMenuItem();
            pictureBox1 = new PictureBox();
            textBox_Year = new TextBox();
            label6 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnRefresh).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnSave).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnDelete).BeginInit();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.BackgroundColor = Color.LightYellow;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 290);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.Size = new Size(752, 209);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // textBox_Win
            // 
            textBox_Win.BackColor = Color.LightYellow;
            textBox_Win.Location = new Point(621, 36);
            textBox_Win.Name = "textBox_Win";
            textBox_Win.Size = new Size(143, 23);
            textBox_Win.TabIndex = 1;
            // 
            // textBox_Mileage
            // 
            textBox_Mileage.BackColor = Color.LightYellow;
            textBox_Mileage.Location = new Point(621, 65);
            textBox_Mileage.Name = "textBox_Mileage";
            textBox_Mileage.Size = new Size(143, 23);
            textBox_Mileage.TabIndex = 2;
            // 
            // textBox_TD
            // 
            textBox_TD.BackColor = Color.LightYellow;
            textBox_TD.Location = new Point(621, 94);
            textBox_TD.Multiline = true;
            textBox_TD.Name = "textBox_TD";
            textBox_TD.Size = new Size(143, 47);
            textBox_TD.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 11.25F);
            label1.Location = new Point(524, 38);
            label1.Name = "label1";
            label1.Size = new Size(85, 18);
            label1.TabIndex = 4;
            label1.Text = "WIN номер";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 11.25F);
            label2.Location = new Point(524, 70);
            label2.Name = "label2";
            label2.Size = new Size(54, 18);
            label2.TabIndex = 5;
            label2.Text = "Пробіг";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 11.25F);
            label3.Location = new Point(524, 113);
            label3.Name = "label3";
            label3.Size = new Size(44, 18);
            label3.TabIndex = 6;
            label3.Text = "Опис";
            // 
            // BtnRefresh
            // 
            BtnRefresh.Image = (Image)resources.GetObject("BtnRefresh.Image");
            BtnRefresh.Location = new Point(688, 262);
            BtnRefresh.Name = "BtnRefresh";
            BtnRefresh.Size = new Size(21, 22);
            BtnRefresh.SizeMode = PictureBoxSizeMode.StretchImage;
            BtnRefresh.TabIndex = 7;
            BtnRefresh.TabStop = false;
            BtnRefresh.Click += BtnRefresh_Click;
            // 
            // textBox_Status
            // 
            textBox_Status.BackColor = Color.LightYellow;
            textBox_Status.Location = new Point(621, 147);
            textBox_Status.Name = "textBox_Status";
            textBox_Status.Size = new Size(143, 23);
            textBox_Status.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 11.25F);
            label4.Location = new Point(524, 152);
            label4.Name = "label4";
            label4.Size = new Size(56, 18);
            label4.TabIndex = 10;
            label4.Text = "Статус";
            // 
            // textBox_Search
            // 
            textBox_Search.BackColor = Color.LightYellow;
            textBox_Search.Location = new Point(12, 241);
            textBox_Search.Name = "textBox_Search";
            textBox_Search.Size = new Size(100, 23);
            textBox_Search.TabIndex = 11;
            textBox_Search.TextChanged += textBox_Search_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Bookman Old Style", 14.25F, FontStyle.Bold | FontStyle.Italic);
            label5.Location = new Point(22, 216);
            label5.Name = "label5";
            label5.Size = new Size(80, 22);
            label5.TabIndex = 12;
            label5.Text = "Пошук";
            // 
            // BtnSave
            // 
            BtnSave.Image = (Image)resources.GetObject("BtnSave.Image");
            BtnSave.Location = new Point(742, 262);
            BtnSave.Name = "BtnSave";
            BtnSave.Size = new Size(21, 22);
            BtnSave.SizeMode = PictureBoxSizeMode.StretchImage;
            BtnSave.TabIndex = 13;
            BtnSave.TabStop = false;
            BtnSave.Click += BtnSave_Click;
            // 
            // BtnDelete
            // 
            BtnDelete.Image = (Image)resources.GetObject("BtnDelete.Image");
            BtnDelete.Location = new Point(715, 262);
            BtnDelete.Name = "BtnDelete";
            BtnDelete.Size = new Size(21, 22);
            BtnDelete.SizeMode = PictureBoxSizeMode.StretchImage;
            BtnDelete.TabIndex = 14;
            BtnDelete.TabStop = false;
            BtnDelete.Click += BtnDelete_Click;
            // 
            // BtnChange
            // 
            BtnChange.BackColor = Color.DarkKhaki;
            BtnChange.FlatStyle = FlatStyle.Popup;
            BtnChange.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            BtnChange.Location = new Point(528, 216);
            BtnChange.Name = "BtnChange";
            BtnChange.Size = new Size(236, 22);
            BtnChange.TabIndex = 15;
            BtnChange.Text = "Змінити";
            BtnChange.UseVisualStyleBackColor = false;
            BtnChange.Click += BtnChange_Click;
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = Color.DarkSeaGreen;
            menuStrip1.Items.AddRange(new ToolStripItem[] { AddAutoSM, BtnStaticric, MyContractsSM });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(776, 24);
            menuStrip1.TabIndex = 16;
            menuStrip1.Text = "menuStrip1";
            // 
            // AddAutoSM
            // 
            AddAutoSM.BackColor = Color.ForestGreen;
            AddAutoSM.DropDownItems.AddRange(new ToolStripItem[] { OnBaseSM, SaleCarSM });
            AddAutoSM.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            AddAutoSM.ForeColor = SystemColors.ControlLightLight;
            AddAutoSM.Name = "AddAutoSM";
            AddAutoSM.Size = new Size(88, 20);
            AddAutoSM.Text = "Додати авто";
            // 
            // OnBaseSM
            // 
            OnBaseSM.BackColor = Color.ForestGreen;
            OnBaseSM.ForeColor = SystemColors.ControlLightLight;
            OnBaseSM.Name = "OnBaseSM";
            OnBaseSM.Size = new Size(136, 22);
            OnBaseSM.Text = "В базу";
            OnBaseSM.Click += OnBaseSM_Click;
            // 
            // SaleCarSM
            // 
            SaleCarSM.BackColor = Color.ForestGreen;
            SaleCarSM.ForeColor = SystemColors.ControlLightLight;
            SaleCarSM.Name = "SaleCarSM";
            SaleCarSM.Size = new Size(136, 22);
            SaleCarSM.Text = "На продаж";
            SaleCarSM.Click += SaleCarSM_Click;
            // 
            // BtnStaticric
            // 
            BtnStaticric.BackColor = Color.ForestGreen;
            BtnStaticric.ForeColor = Color.White;
            BtnStaticric.Name = "BtnStaticric";
            BtnStaticric.Size = new Size(80, 20);
            BtnStaticric.Text = "Статистика";
            BtnStaticric.Click += BtnStaticric_Click;
            // 
            // MyContractsSM
            // 
            MyContractsSM.BackColor = Color.ForestGreen;
            MyContractsSM.ForeColor = Color.White;
            MyContractsSM.Name = "MyContractsSM";
            MyContractsSM.Size = new Size(99, 20);
            MyContractsSM.Text = "Мої контракти";
            MyContractsSM.Click += MyContractsSM_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(194, 38);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(314, 237);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 17;
            pictureBox1.TabStop = false;
            // 
            // textBox_Year
            // 
            textBox_Year.BackColor = Color.LightYellow;
            textBox_Year.Location = new Point(621, 176);
            textBox_Year.Name = "textBox_Year";
            textBox_Year.Size = new Size(143, 23);
            textBox_Year.TabIndex = 18;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 11.25F);
            label6.Location = new Point(524, 181);
            label6.Name = "label6";
            label6.Size = new Size(87, 18);
            label6.TabIndex = 19;
            label6.Text = "Рік випуску";
            // 
            // Place
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.OldLace;
            ClientSize = new Size(776, 511);
            Controls.Add(label6);
            Controls.Add(textBox_Year);
            Controls.Add(pictureBox1);
            Controls.Add(BtnChange);
            Controls.Add(BtnDelete);
            Controls.Add(BtnSave);
            Controls.Add(label5);
            Controls.Add(textBox_Search);
            Controls.Add(label4);
            Controls.Add(textBox_Status);
            Controls.Add(BtnRefresh);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBox_TD);
            Controls.Add(textBox_Mileage);
            Controls.Add(textBox_Win);
            Controls.Add(dataGridView1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Place";
            Text = "Cars";
            Load += Place_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnRefresh).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnSave).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnDelete).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private TextBox textBox_Win;
        private TextBox textBox_Mileage;
        private TextBox textBox_TD;
        private Label label1;
        private Label label2;
        private Label label3;
        private PictureBox BtnRefresh;
        private TextBox textBox_Status;
        private Label label4;
        private TextBox textBox_Search;
        private Label label5;
        private PictureBox BtnSave;
        private PictureBox BtnDelete;
        private Button BtnChange;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem AddAutoSM;
        private ToolStripMenuItem OnBaseSM;
        private ToolStripMenuItem SaleCarSM;
        private PictureBox pictureBox1;
        private ToolStripMenuItem BtnStaticric;
        private TextBox textBox_Year;
        private Label label6;
        private ToolStripMenuItem MyContractsSM;
    }
}