﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net.Http;
using System.Text.Json;
using carmarcet.Models;
using carmarcet.Services;


namespace carmarcet
{

    enum RowState
    {
        Existed,
        New,
        Modified,
        ModifiedNew,
        Deleted
    }
    public partial class Place : Form
    {
        private readonly CarApiClient carApiClient;
        private readonly string LOGIN;
        private int selectedRow;

        public Place(string login)
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            LOGIN = login;
            carApiClient = new CarApiClient("https://localhost:7072");
        }

        private async void Place_Load(object sender, EventArgs e)
        {
            CreateColumns();
            await LoadCarsAsync();
        }

        private void CreateColumns()
        {
            dataGridView1.Columns.Add("WIN_Number", "WIN_Number");
            dataGridView1.Columns.Add("Mileage", "Пробіг");
            dataGridView1.Columns.Add("TechnicalData", "Опис");
            dataGridView1.Columns.Add("NameModel", "Модель");
            dataGridView1.Columns.Add("Mark", "Марка");
            dataGridView1.Columns.Add("Status", "Статус");
            dataGridView1.Columns.Add("ReleaseYear", "Рік випуску");
        }

        private async Task LoadCarsAsync(string? search = null)
        {
            dataGridView1.Rows.Clear();
            var cars = await carApiClient.GetCarsByDealerAsync(LOGIN, search);
            if (cars == null)
            {
                MessageBox.Show("Не знайдено автомобілів.");
                return;
            }

            foreach (var car in cars)
            {
                dataGridView1.Rows.Add(
                    car.WIN_Number, car.Mileage, car.TechnicalData, car.NameModel,
                    car.Mark, car.Status, car.ReleaseYear
                );
            }
        }

        private async void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            selectedRow = e.RowIndex;
            var row = dataGridView1.Rows[selectedRow];

            textBox_Win.Text = row.Cells[0].Value?.ToString();
            textBox_Mileage.Text = row.Cells[1].Value?.ToString();
            textBox_TD.Text = row.Cells[2].Value?.ToString();
            textBox_Status.Text = row.Cells[5].Value?.ToString();
            textBox_Year.Text = row.Cells[6].Value?.ToString();

            var photo = await carApiClient.GetCarPhotoAsync(textBox_Win.Text);
            pictureBox1.Image = photo != null ? ByteArrayToBitmap(photo) : null;
        }

        private Bitmap ByteArrayToBitmap(byte[] byteArray)
        {
            using MemoryStream stream = new MemoryStream(byteArray);
            return new Bitmap(stream);
        }

        private async void BtnDelete_Click(object sender, EventArgs e)
        {
            var win = textBox_Win.Text;
            if (string.IsNullOrEmpty(win)) return;

            var confirm = MessageBox.Show($"Видалити авто {win}?", "Підтвердження", MessageBoxButtons.YesNo);
            if (confirm != DialogResult.Yes) return;

            bool success = await carApiClient.DeleteCarAsync(win);
            MessageBox.Show(success ? "Успішно видалено" : "Помилка при видаленні");
            await LoadCarsAsync();
        }

        private async void BtnSave_Click(object sender, EventArgs e)
        {
            var car = new CarDto
            {
                WIN_Number = textBox_Win.Text,
                Mileage = int.Parse(textBox_Mileage.Text),
                TechnicalData = textBox_TD.Text,
                Status = textBox_Status.Text,
                ReleaseYear = int.Parse(textBox_Year.Text)
            };

            bool success = await carApiClient.UpdateCarAsync(car);
            MessageBox.Show(success ? "Оновлено" : "Помилка оновлення");
            await LoadCarsAsync();
        }

        private async void textBox_Search_TextChanged(object sender, EventArgs e)
        {
            await LoadCarsAsync(textBox_Search.Text);
        }

        private async void BtnRefresh_Click(object sender, EventArgs e)
        {
            await LoadCarsAsync();
        }

        private void BtnChange_Click(object sender, EventArgs e)
        {
            var selectedRowIndex = dataGridView1.CurrentCell.RowIndex;

            var win = textBox_Win.Text;
            var mileage = textBox_Mileage.Text;
            var td = textBox_TD.Text;
            var status = textBox_Status.Text;
            var year = textBox_Year.Text;

            if (dataGridView1.Rows[selectedRowIndex].Cells[0].Value?.ToString() != string.Empty)
            {
                dataGridView1.Rows[selectedRowIndex].SetValues(win, mileage, td, "", "", status, year);
            }
        }

        private void SaleCarSM_Click(object sender, EventArgs e) => ShowDialogForm(new SaleDealer(LOGIN));
        private void OnBaseSM_Click(object sender, EventArgs e) => ShowDialogForm(new AddCar(LOGIN));
        private void BtnStaticric_Click(object sender, EventArgs e) => ShowDialogForm(new Statistic());
        private void MyContractsSM_Click(object sender, EventArgs e) => ShowDialogForm(new MyContracts(LOGIN));

        private void ShowDialogForm(Form f)
        {
            Hide();
            f.ShowDialog();
            Show();
        }
    }




}
