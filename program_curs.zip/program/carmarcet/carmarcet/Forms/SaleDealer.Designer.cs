﻿namespace carmarcet
{
    partial class SaleDealer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SaleDealer));
            dataGridView1 = new DataGridView();
            dataGridView2 = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            textBox_WIN = new TextBox();
            textBox_Price = new TextBox();
            textBox_Login = new TextBox();
            BtnAddSale = new Button();
            label3 = new Label();
            label4 = new Label();
            label6 = new Label();
            label7 = new Label();
            BtnRefresh = new PictureBox();
            BtnDeleteCarSale = new PictureBox();
            BtnClear = new Button();
            dateTimePicker1 = new DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnRefresh).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnDeleteCarSale).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.BackgroundColor = Color.LightYellow;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(200, 73);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.Size = new Size(452, 246);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // dataGridView2
            // 
            dataGridView2.AllowUserToAddRows = false;
            dataGridView2.AllowUserToDeleteRows = false;
            dataGridView2.BackgroundColor = Color.LightYellow;
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(673, 73);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.ReadOnly = true;
            dataGridView2.Size = new Size(352, 246);
            dataGridView2.TabIndex = 1;
            dataGridView2.CellClick += dataGridView2_CellClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Bookman Old Style", 20.25F, FontStyle.Bold);
            label1.Location = new Point(673, 38);
            label1.Name = "label1";
            label1.Size = new Size(108, 32);
            label1.TabIndex = 2;
            label1.Text = "В базі:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Bookman Old Style", 20.25F, FontStyle.Bold);
            label2.Location = new Point(200, 38);
            label2.Name = "label2";
            label2.Size = new Size(173, 32);
            label2.TabIndex = 3;
            label2.Text = "В продажі:";
            // 
            // textBox_WIN
            // 
            textBox_WIN.BackColor = Color.LightYellow;
            textBox_WIN.Location = new Point(29, 73);
            textBox_WIN.Name = "textBox_WIN";
            textBox_WIN.Size = new Size(140, 23);
            textBox_WIN.TabIndex = 4;
            // 
            // textBox_Price
            // 
            textBox_Price.BackColor = Color.LightYellow;
            textBox_Price.Location = new Point(29, 256);
            textBox_Price.Name = "textBox_Price";
            textBox_Price.Size = new Size(140, 23);
            textBox_Price.TabIndex = 6;
            // 
            // textBox_Login
            // 
            textBox_Login.BackColor = Color.LightYellow;
            textBox_Login.Location = new Point(29, 202);
            textBox_Login.Name = "textBox_Login";
            textBox_Login.ReadOnly = true;
            textBox_Login.Size = new Size(140, 23);
            textBox_Login.TabIndex = 7;
            // 
            // BtnAddSale
            // 
            BtnAddSale.BackColor = Color.Olive;
            BtnAddSale.FlatStyle = FlatStyle.Popup;
            BtnAddSale.Location = new Point(29, 296);
            BtnAddSale.Name = "BtnAddSale";
            BtnAddSale.Size = new Size(140, 23);
            BtnAddSale.TabIndex = 8;
            BtnAddSale.Text = "Додати на продаж";
            BtnAddSale.UseVisualStyleBackColor = false;
            BtnAddSale.Click += BtnAddSale_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Bookman Old Style", 12F, FontStyle.Bold);
            label3.Location = new Point(29, 51);
            label3.Name = "label3";
            label3.Size = new Size(103, 19);
            label3.TabIndex = 9;
            label3.Text = "WIN номер";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Bookman Old Style", 12F, FontStyle.Bold);
            label4.Location = new Point(29, 115);
            label4.Name = "label4";
            label4.Size = new Size(145, 19);
            label4.TabIndex = 10;
            label4.Text = "Дата на продаж";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Bookman Old Style", 12F, FontStyle.Bold);
            label6.Location = new Point(29, 180);
            label6.Name = "label6";
            label6.Size = new Size(96, 19);
            label6.TabIndex = 12;
            label6.Text = "Ваш логін";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Bookman Old Style", 12F, FontStyle.Bold);
            label7.Location = new Point(29, 234);
            label7.Name = "label7";
            label7.Size = new Size(49, 19);
            label7.TabIndex = 13;
            label7.Text = "Ціна";
            // 
            // BtnRefresh
            // 
            BtnRefresh.Image = (Image)resources.GetObject("BtnRefresh.Image");
            BtnRefresh.Location = new Point(987, 12);
            BtnRefresh.Name = "BtnRefresh";
            BtnRefresh.Size = new Size(38, 35);
            BtnRefresh.SizeMode = PictureBoxSizeMode.StretchImage;
            BtnRefresh.TabIndex = 14;
            BtnRefresh.TabStop = false;
            BtnRefresh.Click += BtnRefresh_Click;
            // 
            // BtnDeleteCarSale
            // 
            BtnDeleteCarSale.Image = (Image)resources.GetObject("BtnDeleteCarSale.Image");
            BtnDeleteCarSale.Location = new Point(943, 12);
            BtnDeleteCarSale.Name = "BtnDeleteCarSale";
            BtnDeleteCarSale.Size = new Size(38, 35);
            BtnDeleteCarSale.SizeMode = PictureBoxSizeMode.StretchImage;
            BtnDeleteCarSale.TabIndex = 15;
            BtnDeleteCarSale.TabStop = false;
            BtnDeleteCarSale.Click += BtnDeleteCarSale_Click;
            // 
            // BtnClear
            // 
            BtnClear.Location = new Point(29, 12);
            BtnClear.Name = "BtnClear";
            BtnClear.Size = new Size(75, 23);
            BtnClear.TabIndex = 16;
            BtnClear.Text = "Очистити";
            BtnClear.UseVisualStyleBackColor = true;
            BtnClear.Click += BtnClear_Click;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(29, 137);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(140, 23);
            dateTimePicker1.TabIndex = 17;
            // 
            // SaleDealer
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.OldLace;
            ClientSize = new Size(1037, 343);
            Controls.Add(dateTimePicker1);
            Controls.Add(BtnClear);
            Controls.Add(BtnDeleteCarSale);
            Controls.Add(BtnRefresh);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(BtnAddSale);
            Controls.Add(textBox_Login);
            Controls.Add(textBox_Price);
            Controls.Add(textBox_WIN);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dataGridView2);
            Controls.Add(dataGridView1);
            Name = "SaleDealer";
            Text = "SaleDealer";
            Load += SaleDealer_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnRefresh).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnDeleteCarSale).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private DataGridView dataGridView2;
        private Label label1;
        private Label label2;
        private TextBox textBox_WIN;
        private TextBox textBox_Price;
        private TextBox textBox_Login;
        private Button BtnAddSale;
        private Label label3;
        private Label label4;
        private Label label6;
        private Label label7;
        private PictureBox BtnRefresh;
        private PictureBox BtnDeleteCarSale;
        private Button BtnClear;
        private DateTimePicker dateTimePicker1;
    }
}