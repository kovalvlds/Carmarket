﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Forms;
using carmarcet.Models;
using carmarcet.Services;

namespace carmarcet
{
    public partial class SaleDealer : Form
    {
        private readonly string LOGIN;
        private int selectedRow;
        private readonly SaleApiClient saleApiClient;

        public SaleDealer(string login)
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            LOGIN = login;
            saleApiClient = new SaleApiClient("https://localhost:7072");
        }

        private async void SaleDealer_Load(object sender, EventArgs e)
        {
            CreateColumnsSale();
            CreateColumnsBase();
            textBox_Login.Text = LOGIN;
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "yyyy-MM-dd";
            dateTimePicker1.Value = DateTime.Today;

            await LoadDataAsync();
        }

        private async Task LoadDataAsync()
        {
            await RefreshDataGridSaleAsync();
            await RefreshDataGridBaseAsync();
        }

        private void CreateColumnsSale()
        {
            dataGridView1.Columns.Add("WIN_Number", "WIN_Number");
            dataGridView1.Columns.Add("IssueDate", "Дата на продаж");
            dataGridView1.Columns.Add("IdDealer", "ІН_Диллер");
            dataGridView1.Columns.Add("Price", "Ціна");
        }

        private void CreateColumnsBase()
        {
            dataGridView2.Columns.Add("WIN_Number", "WIN_Number");
            dataGridView2.Columns.Add("NameModel", "Модель");
            dataGridView2.Columns.Add("Status", "Статус");
        }

        private async Task RefreshDataGridSaleAsync()
        {
            dataGridView1.Rows.Clear();
            var sales = await saleApiClient.GetAllSalesAsync();
            if (sales == null) return;

            foreach (var sale in sales)
            {
                dataGridView1.Rows.Add(sale.WIN_Number, sale.IssueDate, sale.IdDealer, sale.Price);
            }
        }

        private async Task RefreshDataGridBaseAsync()
        {
            dataGridView2.Rows.Clear();
            var cars = await saleApiClient.GetInactiveCarsAsync(LOGIN);
            if (cars == null) return;

            foreach (var car in cars)
            {
                if (car.Status == "неактивна")
                    dataGridView2.Rows.Add(car.WIN_Number, car.NameModel, car.Status);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            selectedRow = e.RowIndex;
            var row = dataGridView1.Rows[selectedRow];

            textBox_WIN.Text = row.Cells[0].Value?.ToString();
            dateTimePicker1.Value = DateTime.Parse(row.Cells[1].Value.ToString());
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            selectedRow = e.RowIndex;
            var row = dataGridView2.Rows[selectedRow];

            textBox_WIN.Text = row.Cells[0].Value?.ToString();
        }

        private void Clear()
        {
            textBox_WIN.Clear();
            textBox_Price.Clear();
            dateTimePicker1.Value = DateTime.Today;
        }

        private async void BtnAddSale_Click(object sender, EventArgs e)
        {
            var (success, message) = await saleApiClient.AddSaleAsync(
                textBox_WIN.Text,
                LOGIN,
                dateTimePicker1.Value.ToString("yyyy-MM-dd"),
                decimal.Parse(textBox_Price.Text)
            );

            MessageBox.Show(success ? "Авто додано на продаж" : "Помилка: " + message);
            if (success)
            {
                await LoadDataAsync();
                Clear();
            }
        }

        private async void BtnDeleteCarSale_Click(object sender, EventArgs e)
        {
            bool success = await saleApiClient.DeleteSaleAsync(
                textBox_WIN.Text,
                dateTimePicker1.Value.ToString("yyyy-MM-dd")
            );

            MessageBox.Show(success ? "Авто знято з продажу" : "Помилка при видаленні");
            if (success)
            {
                await LoadDataAsync();
                Clear();
            }
        }

        private async void BtnRefresh_Click(object sender, EventArgs e)
        {
            await LoadDataAsync();
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}
