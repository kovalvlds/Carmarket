﻿namespace carmarcet
{
    partial class Singup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_singup = new System.Windows.Forms.Button();
            this.textBox_login = new System.Windows.Forms.TextBox();
            this.textBox_password = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button_singupD = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button_singup
            // 
            this.button_singup.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.button_singup.Location = new System.Drawing.Point(95, 208);
            this.button_singup.Name = "button_singup";
            this.button_singup.Size = new System.Drawing.Size(66, 36);
            this.button_singup.TabIndex = 0;
            this.button_singup.Text = "Клієнт";
            this.button_singup.UseVisualStyleBackColor = true;
            this.button_singup.Click += new System.EventHandler(this.button_singup_Click);
            // 
            // textBox_login
            // 
            this.textBox_login.Location = new System.Drawing.Point(95, 84);
            this.textBox_login.Name = "textBox_login";
            this.textBox_login.Size = new System.Drawing.Size(227, 23);
            this.textBox_login.TabIndex = 1;
            this.textBox_login.TextChanged += new System.EventHandler(this.textBox_login_TextChanged);
            // 
            // textBox_password
            // 
            this.textBox_password.Location = new System.Drawing.Point(95, 136);
            this.textBox_password.Name = "textBox_password";
            this.textBox_password.Size = new System.Drawing.Size(227, 23);
            this.textBox_password.TabIndex = 2;
            this.textBox_password.TextChanged += new System.EventHandler(this.textBox_password_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(99, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(226, 41);
            this.label1.TabIndex = 3;
            this.label1.Text = "Реєстрація";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(141, 173);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "Зареєструватися як:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // button_singupD
            // 
            this.button_singupD.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.button_singupD.Location = new System.Drawing.Point(255, 208);
            this.button_singupD.Name = "button_singupD";
            this.button_singupD.Size = new System.Drawing.Size(66, 36);
            this.button_singupD.TabIndex = 5;
            this.button_singupD.Text = "Диллер";
            this.button_singupD.UseVisualStyleBackColor = true;
            this.button_singupD.Click += new System.EventHandler(this.button_singupD_Click);
            // 
            // Singup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(421, 302);
            this.Controls.Add(this.button_singupD);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_password);
            this.Controls.Add(this.textBox_login);
            this.Controls.Add(this.button_singup);
            this.Name = "Singup";
            this.Text = "SingUp";
            this.Load += new System.EventHandler(this.Singup_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button button_singup;
        private TextBox textBox_login;
        private TextBox textBox_password;
        private Label label1;
        private Label label2;
        private Button button_singupD;
    }
}