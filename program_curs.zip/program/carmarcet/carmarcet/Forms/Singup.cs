﻿using System;
using System.Data;
using System.Drawing;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace carmarcet
{
    public partial class Singup : Form
    {
        public Singup()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void Singup_Load(object sender, EventArgs e)
        {
            textBox_password.PasswordChar = '*';
        }

        private async void button_singup_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox_login.Text) || string.IsNullOrWhiteSpace(textBox_password.Text))
            {
                MessageBox.Show("Будь ласка, введіть логін і пароль!");
                return;
            }

            var loginUser = textBox_login.Text.Trim();
            var passwordUser = textBox_password.Text.Trim();

            var dto = new
            {
                Login = loginUser,
                Password = passwordUser,
                LastName = "",
                IsDealer = false
            };

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:7072");
                    var json = JsonSerializer.Serialize(dto);
                    var content = new StringContent(json, Encoding.UTF8, "application/json");
                    var response = await client.PostAsync("/api/auth/signup", content);

                    if (response.IsSuccessStatusCode)
                    {
                        MessageBox.Show("Аккаунт успішно створено", "Успіх!");
                        ClientAnctcs frm_anct = new ClientAnctcs(loginUser);
                        this.Hide();
                        frm_anct.ShowDialog();
                        this.Show();
                    }
                    else
                    {
                        string respText = await response.Content.ReadAsStringAsync();
                        MessageBox.Show("Помилка: " + respText);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка реєстрації: {ex.Message}");
            }
        }

        private async void button_singupD_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox_login.Text) || string.IsNullOrWhiteSpace(textBox_password.Text))
            {
                MessageBox.Show("Будь ласка, введіть логін і пароль!");
                return;
            }

            var loginUser = textBox_login.Text.Trim();
            var passwordUser = textBox_password.Text.Trim();

            var dto = new
            {
                Login = loginUser,
                Password = passwordUser,
                LastName = "",
                IsDealer = true
            };

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:7072");
                    var json = JsonSerializer.Serialize(dto);
                    var content = new StringContent(json, Encoding.UTF8, "application/json");
                    var response = await client.PostAsync("/api/auth/signup", content);

                    if (response.IsSuccessStatusCode)
                    {
                        MessageBox.Show("Аккаунт успішно створено", "Успіх!");
                        DealerAnctcs frm_anct = new DealerAnctcs(loginUser);
                        this.Hide();
                        frm_anct.ShowDialog();
                        this.Show();
                    }
                    else
                    {
                        string respText = await response.Content.ReadAsStringAsync();
                        MessageBox.Show("Помилка: " + respText);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка реєстрації: {ex.Message}");
            }
        }

        private void label1_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void textBox_login_TextChanged(object sender, EventArgs e) { }
        private void textBox_password_TextChanged(object sender, EventArgs e) { }
    }
}
