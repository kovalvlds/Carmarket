﻿namespace carmarcet
{
    partial class Statistic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            Btn_Find = new Button();
            chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            BtnSum = new Button();
            BtnClient = new Button();
            ((System.ComponentModel.ISupportInitialize)chart1).BeginInit();
            SuspendLayout();
            // 
            // Btn_Find
            // 
            Btn_Find.BackColor = Color.Khaki;
            Btn_Find.FlatStyle = FlatStyle.Popup;
            Btn_Find.Location = new Point(29, 33);
            Btn_Find.Name = "Btn_Find";
            Btn_Find.Size = new Size(129, 84);
            Btn_Find.TabIndex = 1;
            Btn_Find.Text = "Дізнатися кількість проданих автомобілів за місяць";
            Btn_Find.UseVisualStyleBackColor = false;
            Btn_Find.Click += Btn_Find_Click;
            // 
            // chart1
            // 
            chartArea1.Name = "ChartArea1";
            chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            chart1.Legends.Add(legend1);
            chart1.Location = new Point(226, 12);
            chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            chart1.Series.Add(series1);
            chart1.Size = new Size(422, 426);
            chart1.TabIndex = 2;
            chart1.Text = "chart1";
            // 
            // BtnSum
            // 
            BtnSum.BackColor = Color.Khaki;
            BtnSum.FlatStyle = FlatStyle.Popup;
            BtnSum.Location = new Point(29, 132);
            BtnSum.Name = "BtnSum";
            BtnSum.Size = new Size(129, 93);
            BtnSum.TabIndex = 3;
            BtnSum.Text = "Дізнатися на яку суму продав автомобілів кожен диллер";
            BtnSum.UseVisualStyleBackColor = false;
            BtnSum.Click += BtnSum_Click;
            // 
            // BtnClient
            // 
            BtnClient.BackColor = Color.Khaki;
            BtnClient.FlatStyle = FlatStyle.Popup;
            BtnClient.Location = new Point(29, 244);
            BtnClient.Name = "BtnClient";
            BtnClient.Size = new Size(129, 93);
            BtnClient.TabIndex = 4;
            BtnClient.Text = "Дізнатися скільки певні клієнти купили машин";
            BtnClient.UseVisualStyleBackColor = false;
            BtnClient.Click += BtnClient_Click;
            // 
            // Statistic
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.OldLace;
            ClientSize = new Size(660, 450);
            Controls.Add(BtnClient);
            Controls.Add(BtnSum);
            Controls.Add(chart1);
            Controls.Add(Btn_Find);
            Name = "Statistic";
            Text = "Statistic";
            ((System.ComponentModel.ISupportInitialize)chart1).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Button Btn_Find;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private Button BtnSum;
        private Button BtnClient;
    }
}