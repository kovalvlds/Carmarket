﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using carmarcet.Models;
using carmarcet.Services;

namespace carmarcet
{
    public partial class Statistic : Form
    {
        private readonly StatisticApiClient statClient;

        public Statistic()
        {
            InitializeComponent();
            statClient = new StatisticApiClient("https://localhost:7072");
        }

        private void InitializePlot(string title, string xTitle, string yTitle)
        {
            chart1.Series.Clear();
            chart1.ChartAreas.Clear();
            chart1.Titles.Clear();

            chart1.Titles.Add(title);
            chart1.ChartAreas.Add("ChartArea");
            chart1.ChartAreas["ChartArea"].AxisX.Title = xTitle;
            chart1.ChartAreas["ChartArea"].AxisY.Title = yTitle;
        }

        private async void LoadMonthlyContractsAsync()
        {
            try
            {
                InitializePlot("Кількість контрактів по місяцях", "Місяць", "Кількість");
                var stats = await statClient.GetMonthlyStatsAsync();
                if (stats == null) return;

                var series = new Series("Кількість контрактів")
                {
                    ChartType = SeriesChartType.Column,
                    Color = Color.Yellow
                };

                foreach (var stat in stats)
                    series.Points.AddXY(stat.Month, stat.ContractCount);

                chart1.Series.Add(series);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при завантаженні: " + ex.Message);
            }
        }

        private async void LoadDealerEarningsAsync()
        {
            try
            {
                InitializePlot("Сума заробітку по дилерах", "Id дилера", "Заробіток");
                var stats = await statClient.GetDealerEarningsAsync();
                if (stats == null) return;

                var series = new Series("Заробіток дилерів")
                {
                    ChartType = SeriesChartType.Bar,
                    Color = Color.Yellow
                };

                foreach (var stat in stats)
                    series.Points.AddXY(stat.IdDealer, stat.Earnings);

                chart1.Series.Add(series);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при завантаженні: " + ex.Message);
            }
        }

        private async void LoadClientContractsAsync()
        {
            try
            {
                InitializePlot("Кількість контрактів по клієнтах", "Id клієнта", "Кількість");
                var stats = await statClient.GetClientContractsAsync();
                if (stats == null) return;

                var series = new Series("Контракти клієнтів")
                {
                    ChartType = SeriesChartType.Bar,
                    Color = Color.Yellow
                };

                foreach (var stat in stats)
                    series.Points.AddXY(stat.IdClient, stat.ContractCount);

                chart1.Series.Add(series);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при завантаженні: " + ex.Message);
            }
        }

        private void Btn_Find_Click(object sender, EventArgs e) => LoadMonthlyContractsAsync();
        private void BtnSum_Click(object sender, EventArgs e) => LoadDealerEarningsAsync();
        private void BtnClient_Click(object sender, EventArgs e) => LoadClientContractsAsync();
    }
}
