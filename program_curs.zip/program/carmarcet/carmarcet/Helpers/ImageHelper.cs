﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace carmarcet.Helpers
{
    public static class ImageHelper
    {
        public static byte[]? LoadImageAsBytes(string path)
        {
            if (!File.Exists(path)) return null;
            return File.ReadAllBytes(path);
        }

        public static Image? ConvertBytesToImage(byte[] bytes)
        {
            using MemoryStream ms = new(bytes);
            return Image.FromStream(ms);
        }
    }

}
