﻿namespace carmarcet.Models
{
    public class AuthLoginDto
    {
        public string Login { get; set; }
        public string Password { get; set; }
    }
}
