﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace carmarcet.Models
{
    public class CarDto
    {
        public string WIN_Number { get; set; }
        public int Mileage { get; set; }
        public string TechnicalData { get; set; }
        public string NameModel { get; set; }
        public string Mark { get; set; }
        public string Status { get; set; }
        public int ReleaseYear { get; set; }
        public byte[]? CarPhoto { get; set; }
        public string Login { get; set; }
    }
}
