﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace carmarcet.Models
{
    public class ClientContractsDto
    {
        public int IdClient { get; set; }
        public int ContractCount { get; set; }
    }
}
