﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace carmarcet.Models
{
    public class ContractDto
    {
        public int IdContract { get; set; }
        public DateTime ContractDate { get; set; }
        public int IdClient { get; set; }
        public string WIN_Number { get; set; }
        public DateTime IssueDate { get; set; }
    }
}
