﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace carmarcet.Models
{
    public class DealerEarningsDto
    {
        public int IdDealer { get; set; }
        public decimal Earnings { get; set; }
    }
}
