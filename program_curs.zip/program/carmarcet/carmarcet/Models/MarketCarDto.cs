﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace carmarcet.Models
{
    public class MarketCarDto
    {
        public string WIN_Number { get; set; }
        public int Mileage { get; set; }
        public string NameModel { get; set; }
        public string Mark { get; set; }
        public string TechnicalData { get; set; }
        public int ReleaseYear { get; set; }
        public decimal Price { get; set; }
        public string IssueDate { get; set; }
    }

}
