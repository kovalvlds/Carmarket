﻿namespace carmarcet.Models
{
    public class ModelDto
    {
        public string NameModel { get; set; }
        public string Mark { get; set; }
    }
}
