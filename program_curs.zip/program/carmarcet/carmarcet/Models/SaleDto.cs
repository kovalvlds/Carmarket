﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace carmarcet.Models
{
    public class SaleDto
    {
        public string WIN_Number { get; set; }
        public string IssueDate { get; set; }
        public int IdDealer { get; set; }
        public decimal Price { get; set; }
    }
}
