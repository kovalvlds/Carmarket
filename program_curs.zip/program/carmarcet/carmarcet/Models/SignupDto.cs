﻿namespace carmarcet.Models
{
    public class SignupDto
    {
        public string Login { get; set; }
        public string Password { get; set; }
        public string LastName { get; set; } = "";
        public bool IsDealer { get; set; }
    }
}

