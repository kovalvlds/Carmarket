﻿using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using carmarcet.Models;

namespace carmarcet.Services
{
    public class AuthApiClient
    {
        private readonly HttpClient client;

        public AuthApiClient(string baseAddress)
        {
            client = new HttpClient { BaseAddress = new Uri(baseAddress) };
        }

        public async Task<AuthResponseDto?> LoginAsync(AuthLoginDto dto)
        {
            var json = JsonSerializer.Serialize(dto);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await client.PostAsync("/api/auth/login", content);
            return await response.Content.ReadFromJsonAsync<AuthResponseDto>();
        }

        public async Task<(bool Success, string Message)> SignupAsync(SignupDto dto)
        {
            var json = JsonSerializer.Serialize(dto);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await client.PostAsync("/api/auth/signup", content);
            var message = await response.Content.ReadAsStringAsync();

            return (response.IsSuccessStatusCode, message);
        }
    }
}
