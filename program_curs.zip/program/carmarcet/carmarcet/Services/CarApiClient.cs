﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using carmarcet.Models;

namespace carmarcet.Services
{
    public class CarApiClient
    {
        private readonly HttpClient _httpClient;

        public CarApiClient(string baseAddress)
        {
            _httpClient = new HttpClient { BaseAddress = new Uri(baseAddress) };
        }

        public async Task<(bool isSuccess, string error)> AddCarAsync(CarDto car)
        {
            var json = JsonSerializer.Serialize(car);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync("/api/car", content);
            string errorText = await response.Content.ReadAsStringAsync();
            return (response.IsSuccessStatusCode, errorText);
        }

        public async Task<List<CarDto>?> GetCarsByDealerAsync(string login, string? search = null)
        {
            string url = $"/api/car/by-dealer?login={login}";
            if (!string.IsNullOrWhiteSpace(search))
                url += $"&search={search}";

            return await _httpClient.GetFromJsonAsync<List<CarDto>>(url);
        }

        public async Task<byte[]?> GetCarPhotoAsync(string win)
        {
            var response = await _httpClient.GetAsync($"/api/car/photo/{win}");
            return response.IsSuccessStatusCode ? await response.Content.ReadAsByteArrayAsync() : null;
        }

        public async Task<bool> DeleteCarAsync(string win)
        {
            var response = await _httpClient.DeleteAsync($"/api/car/{win}");
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> UpdateCarAsync(CarDto car)
        {
            var json = JsonSerializer.Serialize(car);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _httpClient.PutAsync("/api/car", content);
            return response.IsSuccessStatusCode;
        }
    }
}
