﻿using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace carmarcet.Services
{
    public class CityApiClient
    {
        private readonly HttpClient client;

        public CityApiClient(string baseAddress)
        {
            client = new HttpClient
            {
                BaseAddress = new Uri(baseAddress)
            };
        }

        public async Task<List<string>?> GetAllCitiesAsync()
        {
            var response = await client.GetAsync("/api/city");
            if (!response.IsSuccessStatusCode) return null;

            var json = await response.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<List<string>>(json);
        }

        public async Task<bool> AddCityAsync(string name)
        {
            var json = JsonSerializer.Serialize(new { NameCity = name });
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await client.PostAsync("/api/city", content);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> DeleteCityAsync(string name)
        {
            var response = await client.DeleteAsync($"/api/city/{name}");
            return response.IsSuccessStatusCode;
        }
    }
}
