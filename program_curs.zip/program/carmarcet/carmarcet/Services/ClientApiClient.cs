﻿using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Collections.Generic;
using carmarcet.Models;

namespace carmarcet.Services
{
    public class ClientApiClient
    {
        private readonly HttpClient client;

        public ClientApiClient(string baseAddress)
        {
            client = new HttpClient { BaseAddress = new Uri(baseAddress) };
        }

        public async Task<(bool Success, string Message)> SubmitProfileAsync(ClientDto dto)
        {
            var json = JsonSerializer.Serialize(dto);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await client.PostAsync("/api/client/profile", content);
            string message = await response.Content.ReadAsStringAsync();
            return (response.IsSuccessStatusCode, message);
        }

        // 🔽 ДОДАЙ ЦЕ
        public async Task<List<ClientDto>?> GetAllClientsAsync()
        {
            return await client.GetFromJsonAsync<List<ClientDto>>("/api/client/all");
        }
    }
}
