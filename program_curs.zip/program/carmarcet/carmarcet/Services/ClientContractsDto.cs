﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace carmarcet.Services
{
    public class ClientContractsDto
    {
        public int IdClient { get; set; }
        public int ContractCount { get; set; }
    }
}
