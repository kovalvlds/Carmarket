﻿using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using System.Collections.Generic;
using carmarcet.Models;

namespace carmarcet.Services
{
    public class ContractApiClient
    {
        private readonly HttpClient client;

        public ContractApiClient(string baseAddress)
        {
            client = new HttpClient { BaseAddress = new Uri(baseAddress) };
        }

        // 🔽 Метод для всіх контрактів
        public async Task<List<ContractDto>?> GetAllContractsAsync()
        {
            return await client.GetFromJsonAsync<List<ContractDto>>("/api/contract");
        }

        // 🔽 Метод для видалення
        public async Task<bool> DeleteContractAsync(int id)
        {
            var response = await client.DeleteAsync($"/api/contract/{id}");
            return response.IsSuccessStatusCode;
        }

        // ✅ Новий метод для MyContracts
        public async Task<List<MyContractDto>?> GetContractsByDealerLoginAsync(string login)
        {
            var response = await client.GetAsync($"/api/contract/by-dealer?login={login}");
            if (!response.IsSuccessStatusCode)
                return null;

            return await response.Content.ReadFromJsonAsync<List<MyContractDto>>();
        }
    }
}
