﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using carmarcet.Models;

namespace carmarcet.Services
{
    public class DealerApiClient
    {
        private readonly HttpClient client;

        public DealerApiClient(string baseAddress)
        {
            client = new HttpClient { BaseAddress = new Uri(baseAddress) };
        }

        public async Task<(bool Success, string Message)> SubmitProfileAsync(DealerDto dto)
        {
            var json = JsonSerializer.Serialize(dto);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await client.PostAsync("/api/dealer/profile", content);
            var message = await response.Content.ReadAsStringAsync();

            return (response.IsSuccessStatusCode, message);
        }

        public async Task<List<DealerDto>?> GetAllDealersAsync()
        {
            return await client.GetFromJsonAsync<List<DealerDto>>("/api/dealer/all");
        }
    }
}
