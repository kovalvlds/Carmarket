﻿using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace carmarcet.Services
{
    public class MarkApiClient
    {
        private readonly HttpClient client;

        public MarkApiClient(string baseAddress)
        {
            client = new HttpClient { BaseAddress = new Uri(baseAddress) };
        }

        public async Task<List<string>?> GetAllMarksAsync()
        {
            var response = await client.GetAsync("/api/mark");
            if (!response.IsSuccessStatusCode) return null;

            var json = await response.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<List<string>>(json);
        }

        public async Task<bool> AddMarkAsync(string name)
        {
            var json = JsonSerializer.Serialize(new { Mark = name });
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await client.PostAsync("/api/mark", content);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> DeleteMarkAsync(string name)
        {
            var response = await client.DeleteAsync($"/api/mark/{name}");
            return response.IsSuccessStatusCode;
        }
    }
}
