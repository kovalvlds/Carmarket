﻿using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Collections.Generic;
using carmarcet.Models;

namespace carmarcet.Services
{
    public class MarketApiClient
    {
        private readonly HttpClient client;

        public MarketApiClient(string baseAddress)
        {
            client = new HttpClient { BaseAddress = new Uri(baseAddress) };
        }

        public async Task<List<MarketCarDto>?> GetAvailableCarsAsync()
        {
            return await client.GetFromJsonAsync<List<MarketCarDto>>("/api/market");
        }

        public async Task<byte[]?> GetCarPhotoAsync(string winNumber)
        {
            var response = await client.GetAsync($"/api/car/photo/{winNumber}");
            return response.IsSuccessStatusCode ? await response.Content.ReadAsByteArrayAsync() : null;
        }

        public async Task<(bool Success, string Message)> BuyCarAsync(BuyContractDto dto)
        {
            var json = JsonSerializer.Serialize(dto);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await client.PostAsync("/api/market/contract", content);

            var message = await response.Content.ReadAsStringAsync();
            return (response.IsSuccessStatusCode, message);
        }
    }
}

