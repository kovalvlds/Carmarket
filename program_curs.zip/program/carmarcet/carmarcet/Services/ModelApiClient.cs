﻿using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using carmarcet.Models;

namespace carmarcet.Services
{
    public class ModelApiClient
    {
        private readonly HttpClient client;

        public ModelApiClient(string baseAddress)
        {
            client = new HttpClient { BaseAddress = new Uri(baseAddress) };
        }

        public async Task<List<ModelDto>?> GetAllModelsAsync()
        {
            var response = await client.GetAsync("/api/model");
            if (!response.IsSuccessStatusCode) return null;

            var json = await response.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<List<ModelDto>>(json, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        }

        public async Task<bool> AddModelAsync(ModelDto model)
        {
            var json = JsonSerializer.Serialize(model);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await client.PostAsync("/api/model", content);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> DeleteModelAsync(string nameModel)
        {
            var response = await client.DeleteAsync($"/api/model/{nameModel}");
            return response.IsSuccessStatusCode;
        }
    }
}
