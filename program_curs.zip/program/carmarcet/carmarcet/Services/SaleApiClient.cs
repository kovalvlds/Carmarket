﻿using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Collections.Generic;
using carmarcet.Models;

namespace carmarcet.Services
{
    public class SaleApiClient
    {
        private readonly HttpClient client;

        public SaleApiClient(string baseAddress)
        {
            client = new HttpClient { BaseAddress = new Uri(baseAddress) };
        }

        public async Task<List<SaleDto>?> GetAllSalesAsync()
        {
            return await client.GetFromJsonAsync<List<SaleDto>>("/api/sale");
        }

        public async Task<List<CarDto>?> GetInactiveCarsAsync(string login)
        {
            var url = $"/api/car/by-dealer?login={login}&search=неактивна";
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
                return null;

            return await response.Content.ReadFromJsonAsync<List<CarDto>>();
        }

        public async Task<(bool Success, string Message)> AddSaleAsync(string win, string login, string issueDate, decimal price)
        {
            var dto = new
            {
                WIN_Number = win,
                IssueDate = issueDate,
                Login = login,
                Price = price
            };

            var json = JsonSerializer.Serialize(dto);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await client.PostAsync("/api/sale", content);
            var message = await response.Content.ReadAsStringAsync();

            return (response.IsSuccessStatusCode, message);
        }

        public async Task<bool> DeleteSaleAsync(string win, string issueDate)
        {
            var url = $"/api/sale?win={win}&date={issueDate}";
            var response = await client.DeleteAsync(url);
            return response.IsSuccessStatusCode;
        }
    }
}
