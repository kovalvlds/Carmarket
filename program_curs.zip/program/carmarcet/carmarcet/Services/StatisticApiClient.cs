﻿using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using System.Collections.Generic;
using carmarcet.Models;

namespace carmarcet.Services
{
    public class StatisticApiClient
    {
        private readonly HttpClient client;

        public StatisticApiClient(string baseAddress)
        {
            client = new HttpClient { BaseAddress = new Uri(baseAddress) };
        }

        public async Task<List<MonthStatDto>?> GetMonthlyStatsAsync()
        {
            return await client.GetFromJsonAsync<List<MonthStatDto>>("/api/stat/monthly");
        }

        public async Task<List<DealerEarningsDto>?> GetDealerEarningsAsync()
        {
            return await client.GetFromJsonAsync<List<DealerEarningsDto>>("/api/stat/dealer");
        }

        public async Task<List<ClientContractsDto>?> GetClientContractsAsync()
        {
            return await client.GetFromJsonAsync<List<ClientContractsDto>>("/api/stat/client");
        }
    }
}
